# EcomProfit — E-commerce Profit & Loss Tracker

## Overview

A SaaS platform for tracking e-commerce profit and loss. Connects order data from Shopify stores, tracks courier returns (PostEx, TCS, Leopards, etc.), packaging costs, shipping costs, and generates monthly P&L reports.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite (artifacts/ecom-profit) — deployed at `/`
- **API framework**: Express 5 (artifacts/api-server) — deployed at `/api`
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Charts**: Recharts

## Features

- Dashboard with monthly KPIs (net profit, revenue, orders, delivery/return rates)
- 6-month profit & revenue trend charts
- Order management (add/edit/delete, filter by store/status/month)
- Store management (Shopify, manual, WooCommerce, other)
- Shipment tracking (PostEx, TCS, Leopards, BlueEx, M&P, Trax, Swyft)
- Cost tracking (shipping, packaging, other)
- Monthly P&L reports with full breakdown

## Database Tables

- `stores` — e-commerce stores
- `orders` — individual orders with pricing, status, courier info
- `shipments` — courier shipment tracking
- `costs` — monthly cost entries (shipping, packaging, other)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)

## API Routes

- `GET/POST /api/stores` — list/create stores
- `GET/PUT/DELETE /api/stores/:id` — store CRUD
- `GET/POST /api/orders` — list/create orders (with filters)
- `GET/PUT/DELETE /api/orders/:id` — order CRUD
- `POST /api/orders/bulk-import` — bulk import orders
- `GET/POST /api/shipments` — list/create shipments
- `PUT /api/shipments/:id` — update shipment
- `GET/POST /api/costs` — list/create costs
- `PUT/DELETE /api/costs/:id` — cost CRUD
- `GET /api/reports/dashboard` — dashboard summary
- `GET /api/reports/monthly` — monthly P&L report
- `GET /api/reports/trends` — 6-month trend data
- `GET /api/reports/order-breakdown` — order status breakdown

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
