import { pgTable, serial, text, numeric, timestamp } from "drizzle-orm/pg-core";

export const subscriptionsTable = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  clerkUserId: text("clerk_user_id").notNull(),
  userName: text("user_name"),
  userEmail: text("user_email"),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull().default("499"),
  paymentMethod: text("payment_method").notNull(),
  transactionId: text("transaction_id").notNull(),
  senderName: text("sender_name"),
  senderNumber: text("sender_number"),
  referredByCode: text("referred_by_code"),
  status: text("status").notNull().default("pending"),
  rejectionReason: text("rejection_reason"),
  approvedAt: timestamp("approved_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Subscription = typeof subscriptionsTable.$inferSelect;
