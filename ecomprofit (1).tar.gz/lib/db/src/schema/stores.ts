import { pgTable, serial, text, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const storesTable = pgTable("stores", {
  id: serial("id").primaryKey(),
  clerkUserId: text("clerk_user_id"),
  name: text("name").notNull(),
  platform: text("platform").notNull().default("manual"),
  shopifyDomain: text("shopify_domain"),
  shopifyApiToken: text("shopify_api_token"),
  postexApiKey: text("postex_api_key"),
  currency: text("currency").notNull().default("PKR"),
  clientName: text("client_name"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertStoreSchema = createInsertSchema(storesTable).omit({ id: true, createdAt: true });
export type InsertStore = z.infer<typeof insertStoreSchema>;
export type Store = typeof storesTable.$inferSelect;
