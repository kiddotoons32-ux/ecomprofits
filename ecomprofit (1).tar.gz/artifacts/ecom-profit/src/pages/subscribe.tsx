import { useState, useEffect } from "react";
import { useUser } from "@clerk/react";
import { TrendingUp, Copy, CheckCircle, Clock, XCircle, Smartphone, Building2, AlertCircle, Gift } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type PaymentSettings = {
  easypaisaNumber: string;
  bankName: string;
  bankAccount: string;
  bankTitle: string;
  bankIban: string;
};

type SubStatus = "none" | "pending" | "active" | "rejected";

type SubInfo = {
  status: SubStatus;
  subscription: {
    status: string;
    rejectionReason?: string | null;
    transactionId?: string;
  } | null;
};

interface SubscribeProps {
  trialExpired?: boolean;
}

export default function Subscribe({ trialExpired = false }: SubscribeProps) {
  const { user } = useUser();
  const { toast } = useToast();
  const [method, setMethod] = useState<"easypaisa" | "bank">("easypaisa");
  const [settings, setSettings] = useState<PaymentSettings | null>(null);
  const [subInfo, setSubInfo] = useState<SubInfo | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  const urlRef = new URLSearchParams(window.location.search).get("ref") ?? "";
  const [form, setForm] = useState({
    senderName: "",
    senderNumber: "",
    transactionId: "",
    referredByCode: urlRef.toUpperCase(),
  });

  useEffect(() => {
    fetch("/api/settings/payment").then(r => r.json()).then(setSettings).catch(() => {});
    fetch("/api/subscriptions/my", { credentials: "include" }).then(r => r.json()).then(setSubInfo).catch(() => {});
  }, []);

  function copyText(text: string, key: string) {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.transactionId.trim()) {
      toast({ title: "Enter your transaction ID", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/subscriptions", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userName: user?.fullName ?? user?.firstName,
          userEmail: user?.emailAddresses?.[0]?.emailAddress,
          paymentMethod: method,
          transactionId: form.transactionId.trim(),
          senderName: form.senderName.trim() || undefined,
          senderNumber: form.senderNumber.trim() || undefined,
          referredByCode: form.referredByCode.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to submit");
      setSubInfo({ status: "pending", subscription: data });
      toast({ title: "Payment submitted! We'll activate your account within 24 hours." });
    } catch (err: any) {
      toast({ title: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  }

  if (subInfo?.status === "active") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f8fafc] px-4">
        <div className="text-center">
          <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-7 h-7 text-emerald-600" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">You're all set!</h2>
          <p className="text-slate-500 text-sm mb-4">Your subscription is active. Redirecting...</p>
          <Button onClick={() => (window.location.href = "/dashboard")} className="bg-slate-900 text-white">
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  if (subInfo?.status === "pending") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f8fafc] px-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-8 pb-8 text-center">
            <div className="w-14 h-14 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-7 h-7 text-yellow-600" />
            </div>
            <h2 className="text-lg font-bold text-slate-900 mb-2">Payment Under Review</h2>
            <p className="text-slate-500 text-sm mb-1">
              Your payment of <span className="font-semibold text-slate-700">Rs 499</span> is being verified.
            </p>
            <p className="text-slate-400 text-xs">
              Transaction ID: <span className="font-mono">{subInfo.subscription?.transactionId}</span>
            </p>
            <div className="mt-4 bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-xs text-yellow-700">
              Your account will be activated within 24 hours. Please wait patiently.
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc]">
      <nav className="flex items-center gap-2 px-6 py-4 border-b bg-white">
        <TrendingUp className="w-5 h-5 text-emerald-500" />
        <span className="font-bold text-slate-900">EcomProfit</span>
      </nav>

      <div className="max-w-2xl mx-auto px-4 py-10">
        {trialExpired && !subInfo?.status && (
          <div className="mb-6 flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
            <Clock className="w-5 h-5 flex-shrink-0 mt-0.5 text-amber-500" />
            <div>
              <p className="font-semibold mb-0.5">Your 2-month free trial has ended</p>
              <p className="text-amber-700">Pay Rs 499 once to keep full access forever — no ads, no monthly fees.</p>
            </div>
          </div>
        )}

        {subInfo?.status === "rejected" && (
          <div className="mb-6 flex items-start gap-3 bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-700">
            <XCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold mb-0.5">Previous payment rejected</p>
              <p>{subInfo.subscription?.rejectionReason ?? "Payment could not be verified. Please try again."}</p>
            </div>
          </div>
        )}

        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-medium px-3 py-1.5 rounded-full mb-3">
            Lifetime Access — One-time Payment
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Rs <span className="text-emerald-600">499</span>
          </h1>
          <p className="text-slate-500 text-sm">Pay once, use forever. No monthly fees, no ads.</p>
        </div>

        <Card className="mb-5">
          <CardContent className="pt-5">
            <p className="text-sm font-semibold text-slate-700 mb-3">Choose payment method:</p>
            <div className="grid grid-cols-2 gap-3 mb-5">
              <button
                type="button"
                onClick={() => setMethod("easypaisa")}
                className={cn(
                  "flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all text-sm font-medium",
                  method === "easypaisa"
                    ? "border-emerald-500 bg-emerald-50 text-emerald-700"
                    : "border-slate-200 text-slate-600 hover:border-slate-300"
                )}
              >
                <Smartphone className="w-6 h-6" />
                Easypaisa
              </button>
              <button
                type="button"
                onClick={() => setMethod("bank")}
                className={cn(
                  "flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all text-sm font-medium",
                  method === "bank"
                    ? "border-blue-500 bg-blue-50 text-blue-700"
                    : "border-slate-200 text-slate-600 hover:border-slate-300"
                )}
              >
                <Building2 className="w-6 h-6" />
                Bank Transfer
              </button>
            </div>

            {method === "easypaisa" && (
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 mb-4">
                <p className="text-xs font-semibold text-emerald-700 mb-3 uppercase tracking-wide">Send Rs 499 to Easypaisa:</p>
                <div className="space-y-2">
                  <PaymentRow
                    label="Easypaisa Number"
                    value={settings?.easypaisaNumber ?? "03166931898"}
                    onCopy={() => copyText(settings?.easypaisaNumber ?? "03166931898", "ep")}
                    copied={copied === "ep"}
                  />
                </div>
                <p className="text-xs text-emerald-600 mt-3">
                  Open Easypaisa app → Send Money → Enter number → Amount Rs 499 → Send
                </p>
              </div>
            )}

            {method === "bank" && (
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-4">
                <p className="text-xs font-semibold text-blue-700 mb-3 uppercase tracking-wide">Bank Transfer Details:</p>
                {settings?.bankAccount ? (
                  <div className="space-y-2">
                    {settings.bankTitle && <PaymentRow label="Account Title" value={settings.bankTitle} onCopy={() => copyText(settings.bankTitle, "bt")} copied={copied === "bt"} />}
                    {settings.bankName && <PaymentRow label="Bank Name" value={settings.bankName} onCopy={() => copyText(settings.bankName, "bn")} copied={copied === "bn"} />}
                    {settings.bankAccount && <PaymentRow label="Account Number" value={settings.bankAccount} onCopy={() => copyText(settings.bankAccount, "ba")} copied={copied === "ba"} />}
                    {settings.bankIban && <PaymentRow label="IBAN" value={settings.bankIban} onCopy={() => copyText(settings.bankIban, "bi")} copied={copied === "bi"} />}
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-sm text-blue-600">
                    <AlertCircle className="w-4 h-4" />
                    Bank account details not configured yet. Please use Easypaisa.
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-5">
            <p className="text-sm font-semibold text-slate-700 mb-4">After paying, fill in your details:</p>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Your Name</Label>
                  <Input
                    value={form.senderName}
                    onChange={e => setForm({ ...form, senderName: e.target.value })}
                    placeholder="Muhammad Ali"
                    className="mt-1 text-sm"
                  />
                </div>
                <div>
                  <Label className="text-xs">Your Phone Number</Label>
                  <Input
                    value={form.senderNumber}
                    onChange={e => setForm({ ...form, senderNumber: e.target.value })}
                    placeholder="03XX-XXXXXXX"
                    className="mt-1 text-sm"
                  />
                </div>
              </div>
              <div>
                <Label className="text-xs">Transaction ID / Reference Number <span className="text-red-500">*</span></Label>
                <Input
                  value={form.transactionId}
                  onChange={e => setForm({ ...form, transactionId: e.target.value })}
                  placeholder="e.g. EP123456789 or TXN-XXXXX"
                  className="mt-1 text-sm font-mono"
                  required
                />
                <p className="text-xs text-slate-400 mt-1">Find this in your Easypaisa/bank payment receipt</p>
              </div>
              <div>
                <Label className="text-xs flex items-center gap-1.5">
                  <Gift className="w-3.5 h-3.5 text-violet-500" />
                  Referral Code <span className="text-slate-400">(optional)</span>
                </Label>
                <Input
                  value={form.referredByCode}
                  onChange={e => setForm({ ...form, referredByCode: e.target.value.toUpperCase() })}
                  placeholder="Enter friend's code"
                  className="mt-1 text-sm font-mono tracking-widest uppercase"
                  maxLength={8}
                />
                {urlRef && (
                  <p className="text-xs text-violet-600 mt-1 flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> Referral code applied automatically
                  </p>
                )}
              </div>
              <Button
                type="submit"
                className="w-full bg-slate-900 hover:bg-slate-800 text-white"
                disabled={submitting}
              >
                {submitting ? "Submitting..." : "Submit Payment Proof"}
              </Button>
              <p className="text-center text-xs text-slate-400">
                Your account will be activated within 24 hours after verification
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function PaymentRow({ label, value, onCopy, copied }: { label: string; value: string; onCopy: () => void; copied: boolean }) {
  return (
    <div className="flex items-center justify-between bg-white rounded-lg px-3 py-2 border">
      <div>
        <p className="text-[10px] text-slate-400 uppercase tracking-wide">{label}</p>
        <p className="text-sm font-semibold text-slate-800 font-mono">{value}</p>
      </div>
      <button
        type="button"
        onClick={onCopy}
        className="text-slate-400 hover:text-slate-600 transition-colors ml-3"
        title="Copy"
      >
        {copied ? <CheckCircle className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
      </button>
    </div>
  );
}
