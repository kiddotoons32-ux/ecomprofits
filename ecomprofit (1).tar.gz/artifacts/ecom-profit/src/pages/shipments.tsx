import { useState } from "react";
import { Plus, Truck } from "lucide-react";
import {
  useListShipments, useCreateShipment, useUpdateShipment,
  useListOrders, getListShipmentsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { formatPKR } from "@/lib/format";

const STATUS_COLORS: Record<string, string> = {
  in_transit: "bg-blue-100 text-blue-800",
  delivered: "bg-emerald-100 text-emerald-800",
  returned: "bg-red-100 text-red-800",
  failed: "bg-gray-100 text-gray-600",
};

const STATUS_LABELS: Record<string, string> = {
  in_transit: "In Transit", delivered: "Delivered",
  returned: "Returned", failed: "Failed",
};

const COURIERS = ["PostEx", "TCS", "Leopards", "BlueEx", "M&P", "Trax", "Swyft"];

type ShipForm = {
  orderId: string; courier: string; trackingNumber: string;
  status: string; shippingCost: string; dispatchDate: string;
  deliveryDate: string; notes: string;
};

const EMPTY_FORM: ShipForm = {
  orderId: "", courier: "PostEx", trackingNumber: "",
  status: "in_transit", shippingCost: "0",
  dispatchDate: new Date().toISOString().slice(0, 10),
  deliveryDate: "", notes: "",
};

export default function Shipments() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterCourier, setFilterCourier] = useState("all");

  const shipmentsParams = {
    ...(filterStatus !== "all" && { status: filterStatus as "in_transit" | "delivered" | "returned" | "failed" }),
    ...(filterCourier !== "all" && { courier: filterCourier }),
  };

  const { data: shipments, isLoading } = useListShipments(shipmentsParams, {
    query: { queryKey: getListShipmentsQueryKey(shipmentsParams) }
  });
  const { data: ordersPage } = useListOrders({ limit: 200 });
  const createShipment = useCreateShipment();
  const updateShipment = useUpdateShipment();

  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<ShipForm>(EMPTY_FORM);

  function setField(field: keyof ShipForm, value: string) {
    setForm(f => ({ ...f, [field]: value }));
  }

  function openCreate() {
    setEditId(null);
    setForm(EMPTY_FORM);
    setOpen(true);
  }

  function openEdit(s: NonNullable<typeof shipments>[0]) {
    setEditId(s.id);
    setForm({
      orderId: String(s.orderId),
      courier: s.courier,
      trackingNumber: s.trackingNumber,
      status: s.status,
      shippingCost: String(s.shippingCost),
      dispatchDate: s.dispatchDate ?? "",
      deliveryDate: s.deliveryDate ?? "",
      notes: s.notes ?? "",
    });
    setOpen(true);
  }

  function invalidate() {
    qc.invalidateQueries({ queryKey: getListShipmentsQueryKey() });
  }

  async function handleSubmit() {
    if (editId) {
      await updateShipment.mutateAsync({
        id: editId,
        data: {
          status: form.status as "in_transit" | "delivered" | "returned" | "failed",
          shippingCost: parseFloat(form.shippingCost) || 0,
          deliveryDate: form.deliveryDate || null,
          notes: form.notes || null,
        }
      });
      toast({ title: "Shipment updated" });
    } else {
      await createShipment.mutateAsync({
        data: {
          orderId: parseInt(form.orderId),
          courier: form.courier,
          trackingNumber: form.trackingNumber,
          status: form.status as "in_transit" | "delivered" | "returned" | "failed",
          shippingCost: parseFloat(form.shippingCost) || 0,
          dispatchDate: form.dispatchDate || null,
          deliveryDate: form.deliveryDate || null,
          notes: form.notes || null,
        }
      });
      toast({ title: "Shipment added" });
    }
    invalidate();
    setOpen(false);
  }

  const orders = ordersPage?.orders ?? [];

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">Shipments</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Track courier shipments</p>
        </div>
        <Button data-testid="button-add-shipment" size="sm" onClick={openCreate}>
          <Plus className="w-4 h-4 mr-1" /> Add Shipment
        </Button>
      </div>

      <div className="flex gap-2">
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger data-testid="select-filter-shipment-status" className="h-8 w-36 text-sm"><SelectValue placeholder="All Statuses" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {Object.entries(STATUS_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterCourier} onValueChange={setFilterCourier}>
          <SelectTrigger data-testid="select-filter-courier" className="h-8 w-36 text-sm"><SelectValue placeholder="All Couriers" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Couriers</SelectItem>
            {COURIERS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="border rounded-md overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 border-b">
            <tr>
              {["Order #", "Courier", "Tracking", "Status", "Shipping Cost", "Dispatch", "Delivery", ""].map(h => (
                <th key={h} className="text-left px-3 py-2.5 font-medium text-xs text-muted-foreground whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <tr key={i} className="border-b">
                  {Array.from({ length: 8 }).map((_, j) => (
                    <td key={j} className="px-3 py-2"><Skeleton className="h-4 w-full" /></td>
                  ))}
                </tr>
              ))
            ) : !shipments?.length ? (
              <tr>
                <td colSpan={8} className="text-center py-12 text-sm text-muted-foreground">
                  <Truck className="w-8 h-8 mx-auto mb-2 text-muted-foreground/50" />
                  No shipments yet.
                </td>
              </tr>
            ) : (
              shipments.map(s => (
                <tr key={s.id} data-testid={`row-shipment-${s.id}`} className="border-b hover:bg-muted/30 transition-colors">
                  <td className="px-3 py-2 font-mono text-xs font-medium">{s.orderNumber}</td>
                  <td className="px-3 py-2 text-xs font-medium">{s.courier}</td>
                  <td className="px-3 py-2 font-mono text-xs text-muted-foreground">{s.trackingNumber}</td>
                  <td className="px-3 py-2">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[s.status] ?? ""}`}>
                      {STATUS_LABELS[s.status] ?? s.status}
                    </span>
                  </td>
                  <td className="px-3 py-2 tabular-nums text-xs">{formatPKR(Number(s.shippingCost))}</td>
                  <td className="px-3 py-2 text-xs text-muted-foreground">{s.dispatchDate ?? "—"}</td>
                  <td className="px-3 py-2 text-xs text-muted-foreground">{s.deliveryDate ?? "—"}</td>
                  <td className="px-3 py-2">
                    <Button data-testid={`button-edit-shipment-${s.id}`} variant="ghost" size="sm" className="h-6 text-xs" onClick={() => openEdit(s)}>
                      Update
                    </Button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editId ? "Update Shipment" : "Add Shipment"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            {!editId && (
              <>
                <div>
                  <Label>Order</Label>
                  <Select value={form.orderId} onValueChange={v => setField("orderId", v)}>
                    <SelectTrigger data-testid="select-shipment-order"><SelectValue placeholder="Select order" /></SelectTrigger>
                    <SelectContent>
                      {orders.map(o => (
                        <SelectItem key={o.id} value={String(o.id)}>{o.orderNumber} — {o.productName}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Courier</Label>
                    <Select value={form.courier} onValueChange={v => setField("courier", v)}>
                      <SelectTrigger data-testid="select-shipment-courier"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {COURIERS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Tracking Number</Label>
                    <Input data-testid="input-shipment-tracking" value={form.trackingNumber} onChange={e => setField("trackingNumber", e.target.value)} />
                  </div>
                </div>
                <div>
                  <Label>Dispatch Date</Label>
                  <Input data-testid="input-dispatch-date" type="date" value={form.dispatchDate} onChange={e => setField("dispatchDate", e.target.value)} />
                </div>
              </>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Status</Label>
                <Select value={form.status} onValueChange={v => setField("status", v)}>
                  <SelectTrigger data-testid="select-shipment-status"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(STATUS_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Shipping Cost (PKR)</Label>
                <Input data-testid="input-shipping-cost" type="number" value={form.shippingCost} onChange={e => setField("shippingCost", e.target.value)} />
              </div>
            </div>
            <div>
              <Label>Delivery Date</Label>
              <Input data-testid="input-shipment-delivery-date" type="date" value={form.deliveryDate} onChange={e => setField("deliveryDate", e.target.value)} />
            </div>
            <div>
              <Label>Notes</Label>
              <Input data-testid="input-shipment-notes" value={form.notes} onChange={e => setField("notes", e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button data-testid="button-cancel-shipment" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button data-testid="button-save-shipment" onClick={handleSubmit}
              disabled={(!editId && (!form.orderId || !form.trackingNumber)) || createShipment.isPending || updateShipment.isPending}>
              {(createShipment.isPending || updateShipment.isPending) ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
