import { useState } from "react";
import { Plus, Pencil, Trash2, Upload, Search } from "lucide-react";
import {
  useListOrders, useCreateOrder, useUpdateOrder, useDeleteOrder,
  useListStores, getListOrdersQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { formatPKR } from "@/lib/format";

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800",
  delivered: "bg-emerald-100 text-emerald-800",
  returned: "bg-red-100 text-red-800",
  not_delivered: "bg-orange-100 text-orange-800",
  cancelled: "bg-gray-100 text-gray-600",
};

const STATUS_LABELS: Record<string, string> = {
  pending: "Pending", delivered: "Delivered",
  returned: "Returned", not_delivered: "Not Delivered", cancelled: "Cancelled",
};

type OrderForm = {
  storeId: string; orderNumber: string; customerName: string; customerPhone: string;
  productName: string; quantity: string; salePrice: string; costPrice: string;
  shippingCharge: string; packagingCost: string; status: string;
  courier: string; trackingNumber: string; orderDate: string; deliveryDate: string; notes: string;
};

const EMPTY_FORM: OrderForm = {
  storeId: "", orderNumber: "", customerName: "", customerPhone: "",
  productName: "", quantity: "1", salePrice: "", costPrice: "0",
  shippingCharge: "0", packagingCost: "0", status: "pending",
  courier: "", trackingNumber: "", orderDate: new Date().toISOString().slice(0, 10),
  deliveryDate: "", notes: "",
};

const NOW = new Date();
const MONTHS = Array.from({ length: 12 }, (_, i) => i + 1);

export default function Orders() {
  const qc = useQueryClient();
  const { toast } = useToast();

  const [filterStore, setFilterStore] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterMonth, setFilterMonth] = useState(String(NOW.getMonth() + 1));
  const [filterYear, setFilterYear] = useState(String(NOW.getFullYear()));
  const [search, setSearch] = useState("");

  const ordersParams = {
    ...(filterStore !== "all" && { storeId: parseInt(filterStore) }),
    ...(filterStatus !== "all" && { status: filterStatus as "pending" | "delivered" | "returned" | "not_delivered" | "cancelled" }),
    ...(filterMonth !== "all" && { month: parseInt(filterMonth) }),
    ...(filterYear !== "all" && { year: parseInt(filterYear) }),
    limit: 100,
  };

  const { data: ordersPage, isLoading } = useListOrders(ordersParams, {
    query: { queryKey: getListOrdersQueryKey(ordersParams) }
  });
  const { data: stores } = useListStores();
  const createOrder = useCreateOrder();
  const updateOrder = useUpdateOrder();
  const deleteOrder = useDeleteOrder();

  const [open, setOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<OrderForm>(EMPTY_FORM);

  function setField(field: keyof OrderForm, value: string) {
    setForm(f => ({ ...f, [field]: value }));
  }

  function openCreate() {
    setEditId(null);
    setForm({ ...EMPTY_FORM, storeId: stores?.[0] ? String(stores[0].id) : "" });
    setOpen(true);
  }

  function openEdit(order: NonNullable<ReturnType<typeof useListOrders>["data"]>["orders"][0]) {
    setEditId(order.id);
    setForm({
      storeId: String(order.storeId),
      orderNumber: order.orderNumber,
      customerName: order.customerName ?? "",
      customerPhone: order.customerPhone ?? "",
      productName: order.productName,
      quantity: String(order.quantity),
      salePrice: String(order.salePrice),
      costPrice: String(order.costPrice),
      shippingCharge: String(order.shippingCharge),
      packagingCost: String(order.packagingCost),
      status: order.status,
      courier: order.courier ?? "",
      trackingNumber: order.trackingNumber ?? "",
      orderDate: order.orderDate,
      deliveryDate: order.deliveryDate ?? "",
      notes: order.notes ?? "",
    });
    setOpen(true);
  }

  function invalidate() {
    qc.invalidateQueries({ queryKey: getListOrdersQueryKey() });
  }

  async function handleSubmit() {
    const payload = {
      storeId: parseInt(form.storeId),
      orderNumber: form.orderNumber,
      customerName: form.customerName || null,
      customerPhone: form.customerPhone || null,
      productName: form.productName,
      quantity: parseInt(form.quantity) || 1,
      salePrice: parseFloat(form.salePrice) || 0,
      costPrice: parseFloat(form.costPrice) || 0,
      shippingCharge: parseFloat(form.shippingCharge) || 0,
      packagingCost: parseFloat(form.packagingCost) || 0,
      status: form.status as "pending" | "delivered" | "returned" | "not_delivered" | "cancelled",
      courier: form.courier || null,
      trackingNumber: form.trackingNumber || null,
      orderDate: form.orderDate,
      deliveryDate: form.deliveryDate || null,
      notes: form.notes || null,
    };
    if (editId) {
      await updateOrder.mutateAsync({ id: editId, data: payload });
      toast({ title: "Order updated" });
    } else {
      await createOrder.mutateAsync({ data: payload });
      toast({ title: "Order added" });
    }
    invalidate();
    setOpen(false);
  }

  async function handleDelete() {
    if (!deleteId) return;
    await deleteOrder.mutateAsync({ id: deleteId });
    toast({ title: "Order deleted" });
    invalidate();
    setDeleteId(null);
  }

  const orders = ordersPage?.orders ?? [];
  const filtered = search
    ? orders.filter(o =>
        o.orderNumber.toLowerCase().includes(search.toLowerCase()) ||
        o.productName.toLowerCase().includes(search.toLowerCase()) ||
        (o.customerName ?? "").toLowerCase().includes(search.toLowerCase())
      )
    : orders;

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">Orders</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{ordersPage?.total ?? 0} orders found</p>
        </div>
        <div className="flex gap-2">
          <Button data-testid="button-add-order" size="sm" onClick={openCreate}>
            <Plus className="w-4 h-4 mr-1" /> Add Order
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-2.5 top-2 text-muted-foreground" />
          <Input data-testid="input-search-orders" className="pl-8 h-8 w-44 text-sm" placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Select value={filterStore} onValueChange={setFilterStore}>
          <SelectTrigger data-testid="select-filter-store" className="h-8 w-36 text-sm"><SelectValue placeholder="All Stores" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Stores</SelectItem>
            {stores?.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger data-testid="select-filter-status" className="h-8 w-36 text-sm"><SelectValue placeholder="All Statuses" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {Object.entries(STATUS_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterMonth} onValueChange={setFilterMonth}>
          <SelectTrigger data-testid="select-filter-month" className="h-8 w-28 text-sm"><SelectValue placeholder="Month" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Months</SelectItem>
            {MONTHS.map(m => <SelectItem key={m} value={String(m)}>{new Date(2000, m - 1).toLocaleString("en", { month: "short" })}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterYear} onValueChange={setFilterYear}>
          <SelectTrigger data-testid="select-filter-year" className="h-8 w-24 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {[NOW.getFullYear(), NOW.getFullYear() - 1, NOW.getFullYear() - 2].map(y => (
              <SelectItem key={y} value={String(y)}>{y}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="border rounded-md overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 border-b">
            <tr>
              {["Order #", "Store", "Product", "Qty", "Sale Price", "Status", "Courier", "Date", ""].map(h => (
                <th key={h} className="text-left px-3 py-2.5 font-medium text-xs text-muted-foreground whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 8 }).map((_, i) => (
                <tr key={i} className="border-b">
                  {Array.from({ length: 9 }).map((_, j) => (
                    <td key={j} className="px-3 py-2"><Skeleton className="h-4 w-full" /></td>
                  ))}
                </tr>
              ))
            ) : !filtered.length ? (
              <tr>
                <td colSpan={9} className="text-center py-12 text-sm text-muted-foreground">
                  No orders found. Add your first order.
                </td>
              </tr>
            ) : (
              filtered.map(order => (
                <tr key={order.id} data-testid={`row-order-${order.id}`} className="border-b hover:bg-muted/30 transition-colors">
                  <td className="px-3 py-2 font-mono text-xs font-medium">{order.orderNumber}</td>
                  <td className="px-3 py-2 text-xs text-muted-foreground">{order.storeName}</td>
                  <td className="px-3 py-2">
                    <div className="font-medium">{order.productName}</div>
                    {order.customerName && <div className="text-xs text-muted-foreground">{order.customerName}</div>}
                  </td>
                  <td className="px-3 py-2 text-xs tabular-nums">{order.quantity}</td>
                  <td className="px-3 py-2 tabular-nums font-medium text-xs">{formatPKR(Number(order.salePrice) * order.quantity)}</td>
                  <td className="px-3 py-2">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[order.status] ?? ""}`}>
                      {STATUS_LABELS[order.status] ?? order.status}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-xs text-muted-foreground">{order.courier ?? "—"}</td>
                  <td className="px-3 py-2 text-xs text-muted-foreground whitespace-nowrap">{order.orderDate}</td>
                  <td className="px-3 py-2">
                    <div className="flex gap-1">
                      <Button data-testid={`button-edit-order-${order.id}`} variant="ghost" size="icon" className="h-6 w-6" onClick={() => openEdit(order)}>
                        <Pencil className="w-3 h-3" />
                      </Button>
                      <Button data-testid={`button-delete-order-${order.id}`} variant="ghost" size="icon" className="h-6 w-6 text-destructive" onClick={() => setDeleteId(order.id)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editId ? "Edit Order" : "Add Order"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-2">
            <div>
              <Label>Store</Label>
              <Select value={form.storeId} onValueChange={v => setField("storeId", v)}>
                <SelectTrigger data-testid="select-order-store"><SelectValue placeholder="Select store" /></SelectTrigger>
                <SelectContent>
                  {stores?.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Order Number</Label>
              <Input data-testid="input-order-number" value={form.orderNumber} onChange={e => setField("orderNumber", e.target.value)} placeholder="ORD-001" />
            </div>
            <div>
              <Label>Customer Name</Label>
              <Input data-testid="input-customer-name" value={form.customerName} onChange={e => setField("customerName", e.target.value)} />
            </div>
            <div>
              <Label>Customer Phone</Label>
              <Input data-testid="input-customer-phone" value={form.customerPhone} onChange={e => setField("customerPhone", e.target.value)} placeholder="0300XXXXXXX" />
            </div>
            <div className="col-span-2">
              <Label>Product Name</Label>
              <Input data-testid="input-product-name" value={form.productName} onChange={e => setField("productName", e.target.value)} />
            </div>
            <div>
              <Label>Quantity</Label>
              <Input data-testid="input-quantity" type="number" value={form.quantity} onChange={e => setField("quantity", e.target.value)} min={1} />
            </div>
            <div>
              <Label>Sale Price (PKR)</Label>
              <Input data-testid="input-sale-price" type="number" value={form.salePrice} onChange={e => setField("salePrice", e.target.value)} />
            </div>
            <div>
              <Label>Cost Price (PKR)</Label>
              <Input data-testid="input-cost-price" type="number" value={form.costPrice} onChange={e => setField("costPrice", e.target.value)} />
            </div>
            <div>
              <Label>Shipping Charge (PKR)</Label>
              <Input data-testid="input-shipping-charge" type="number" value={form.shippingCharge} onChange={e => setField("shippingCharge", e.target.value)} />
            </div>
            <div>
              <Label>Packaging Cost (PKR)</Label>
              <Input data-testid="input-packaging-cost" type="number" value={form.packagingCost} onChange={e => setField("packagingCost", e.target.value)} />
            </div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={v => setField("status", v)}>
                <SelectTrigger data-testid="select-order-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(STATUS_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Courier</Label>
              <Select value={form.courier || "__none__"} onValueChange={v => setField("courier", v === "__none__" ? "" : v)}>
                <SelectTrigger data-testid="select-courier"><SelectValue placeholder="Select courier" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">None</SelectItem>
                  {["PostEx", "TCS", "Leopards", "BlueEx", "M&P", "Trax", "Swyft"].map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Tracking Number</Label>
              <Input data-testid="input-tracking-number" value={form.trackingNumber} onChange={e => setField("trackingNumber", e.target.value)} />
            </div>
            <div>
              <Label>Order Date</Label>
              <Input data-testid="input-order-date" type="date" value={form.orderDate} onChange={e => setField("orderDate", e.target.value)} />
            </div>
            <div>
              <Label>Delivery Date</Label>
              <Input data-testid="input-delivery-date" type="date" value={form.deliveryDate} onChange={e => setField("deliveryDate", e.target.value)} />
            </div>
            <div className="col-span-2">
              <Label>Notes</Label>
              <Input data-testid="input-notes" value={form.notes} onChange={e => setField("notes", e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button data-testid="button-cancel-order" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button data-testid="button-save-order" onClick={handleSubmit}
              disabled={!form.storeId || !form.orderNumber || !form.productName || !form.salePrice || createOrder.isPending || updateOrder.isPending}>
              {(createOrder.isPending || updateOrder.isPending) ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Order?</AlertDialogTitle>
            <AlertDialogDescription>This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
