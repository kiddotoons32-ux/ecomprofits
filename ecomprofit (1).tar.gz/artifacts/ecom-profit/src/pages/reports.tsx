import { useState } from "react";
import { TrendingUp, TrendingDown, Download } from "lucide-react";
import {
  useGetMonthlyReport, useGetMonthlyTrends, useListStores,
  getGetMonthlyReportQueryKey, getGetMonthlyTrendsQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatPKR, formatPercent, monthName } from "@/lib/format";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  LineChart, Line
} from "recharts";

const NOW = new Date();
const MONTHS = Array.from({ length: 12 }, (_, i) => i + 1);

function Stat({ label, value, className = "" }: { label: string; value: string; className?: string }) {
  return (
    <div className="flex flex-col gap-0.5 p-3 border rounded-md" data-testid={`stat-${label.toLowerCase().replace(/\s+/g,'-')}`}>
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={`font-bold tabular-nums text-sm ${className}`}>{value}</span>
    </div>
  );
}

export default function Reports() {
  const [selectedStore, setSelectedStore] = useState("all");
  const [selectedMonth, setSelectedMonth] = useState(String(NOW.getMonth() + 1));
  const [selectedYear, setSelectedYear] = useState(String(NOW.getFullYear()));

  const { data: stores } = useListStores();
  const storeId = selectedStore !== "all" ? parseInt(selectedStore) : undefined;
  const month = parseInt(selectedMonth);
  const year = parseInt(selectedYear);

  const reportParams = { month, year, ...(storeId && { storeId }) };
  const { data: report, isLoading } = useGetMonthlyReport(reportParams, {
    query: { queryKey: getGetMonthlyReportQueryKey(reportParams) }
  });

  const trendsParams = { months: 6, ...(storeId && { storeId }) };
  const { data: trends } = useGetMonthlyTrends(trendsParams, {
    query: { queryKey: getGetMonthlyTrendsQueryKey(trendsParams) }
  });

  const isProfit = (report?.netProfit ?? 0) >= 0;

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">Monthly Report</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Full profit & loss breakdown</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedStore} onValueChange={setSelectedStore}>
            <SelectTrigger data-testid="select-report-store" className="h-8 w-40 text-sm"><SelectValue placeholder="All Stores" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Stores</SelectItem>
              {stores?.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger data-testid="select-report-month" className="h-8 w-28 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              {MONTHS.map(m => <SelectItem key={m} value={String(m)}>{monthName(m)}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger data-testid="select-report-year" className="h-8 w-24 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              {[NOW.getFullYear(), NOW.getFullYear() - 1, NOW.getFullYear() - 2].map(y => (
                <SelectItem key={y} value={String(y)}>{y}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-32" />
          <div className="grid grid-cols-3 gap-4">
            {Array.from({ length: 9 }).map((_, i) => <Skeleton key={i} className="h-16" />)}
          </div>
        </div>
      ) : report ? (
        <>
          <Card className={`border-l-4 ${isProfit ? "border-l-emerald-500" : "border-l-red-500"}`}>
            <CardContent className="p-5 flex items-center justify-between">
              <div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                  Net Profit/Loss — {monthName(report.month)} {report.year}
                  {report.storeName && <span className="ml-2 font-medium">{report.storeName}</span>}
                </div>
                <div className={`text-3xl font-bold tabular-nums ${isProfit ? "text-emerald-600" : "text-red-600"}`}>
                  {formatPKR(report.netProfit)}
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  Margin: {formatPercent(report.profitMargin)}
                </div>
              </div>
              <div className={`p-4 rounded-full ${isProfit ? "bg-emerald-100" : "bg-red-100"}`}>
                {isProfit
                  ? <TrendingUp className="w-8 h-8 text-emerald-600" />
                  : <TrendingDown className="w-8 h-8 text-red-600" />
                }
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <Stat label="Total Revenue" value={formatPKR(report.totalRevenue)} />
            <Stat label="Gross Profit" value={formatPKR(report.grossProfit)} className={report.grossProfit >= 0 ? "text-emerald-600" : "text-red-600"} />
            <Stat label="Cost of Goods" value={formatPKR(report.totalCostOfGoods)} className="text-destructive" />
            <Stat label="Shipping Costs" value={formatPKR(report.totalShippingCost)} className="text-destructive" />
            <Stat label="Packaging Costs" value={formatPKR(report.totalPackagingCost)} className="text-destructive" />
            <Stat label="Other Costs" value={formatPKR(report.totalOtherCosts)} className="text-destructive" />
          </div>

          <Card>
            <CardHeader className="pb-2 pt-4 px-5">
              <CardTitle className="text-sm font-semibold">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="px-5 pb-4">
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                {[
                  { label: "Total Orders", value: String(report.totalOrders) },
                  { label: "Delivered", value: String(report.deliveredOrders), extra: `(${formatPercent(report.deliveryRate)})` },
                  { label: "Returned", value: String(report.returnedOrders), extra: `(${formatPercent(report.returnRate)})` },
                  { label: "Not Delivered", value: String(report.notDeliveredOrders) },
                  { label: "Pending", value: String(report.pendingOrders) },
                  { label: "Cancelled", value: String(report.cancelledOrders) },
                ].map(({ label, value, extra }) => (
                  <div key={label} className="border rounded-md p-3 text-center" data-testid={`stat-order-${label.toLowerCase().replace(/\s+/g,'-')}`}>
                    <div className="text-2xl font-bold">{value}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
                    {extra && <div className="text-xs text-muted-foreground">{extra}</div>}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {trends && trends.length > 0 && (
            <Card>
              <CardHeader className="pb-2 pt-4 px-5">
                <CardTitle className="text-sm font-semibold">6-Month Trend</CardTitle>
              </CardHeader>
              <CardContent className="px-2 pb-4">
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={trends} margin={{ top: 4, right: 16, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} tickFormatter={v => `${(v / 1000).toFixed(0)}k`} />
                    <Tooltip formatter={(v: number) => formatPKR(v)} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Bar dataKey="revenue" fill="#6366f1" name="Revenue" radius={[2, 2, 0, 0]} />
                    <Bar dataKey="netProfit" fill="#10b981" name="Net Profit" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}
        </>
      ) : (
        <Card>
          <CardContent className="py-16 text-center">
            <p className="text-sm text-muted-foreground">No data for {monthName(month)} {year}. Add some orders to see the report.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
