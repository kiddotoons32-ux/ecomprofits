import { useState } from "react";
import { Plus, Pencil, Trash2, DollarSign } from "lucide-react";
import {
  useListCosts, useCreateCost, useUpdateCost, useDeleteCost,
  useListStores, getListCostsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { formatPKR, monthName } from "@/lib/format";

const TYPE_COLORS: Record<string, string> = {
  shipping: "bg-blue-100 text-blue-800",
  packaging: "bg-amber-100 text-amber-800",
  other: "bg-violet-100 text-violet-800",
};

const NOW = new Date();
const MONTHS = Array.from({ length: 12 }, (_, i) => i + 1);

type CostForm = {
  storeId: string; type: string; description: string;
  amount: string; month: string; year: string;
};

const EMPTY_FORM: CostForm = {
  storeId: "", type: "shipping", description: "",
  amount: "", month: String(NOW.getMonth() + 1), year: String(NOW.getFullYear()),
};

export default function Costs() {
  const qc = useQueryClient();
  const { toast } = useToast();

  const [filterStore, setFilterStore] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [filterMonth, setFilterMonth] = useState(String(NOW.getMonth() + 1));
  const [filterYear, setFilterYear] = useState(String(NOW.getFullYear()));

  const costsParams = {
    ...(filterStore !== "all" && { storeId: parseInt(filterStore) }),
    ...(filterType !== "all" && { type: filterType as "shipping" | "packaging" | "other" }),
    ...(filterMonth !== "all" && { month: parseInt(filterMonth) }),
    ...(filterYear !== "all" && { year: parseInt(filterYear) }),
  };

  const { data: costs, isLoading } = useListCosts(costsParams, {
    query: { queryKey: getListCostsQueryKey(costsParams) }
  });
  const { data: stores } = useListStores();
  const createCost = useCreateCost();
  const updateCost = useUpdateCost();
  const deleteCost = useDeleteCost();

  const [open, setOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<CostForm>(EMPTY_FORM);

  function setField(field: keyof CostForm, value: string) {
    setForm(f => ({ ...f, [field]: value }));
  }

  function openCreate() {
    setEditId(null);
    setForm({ ...EMPTY_FORM, storeId: stores?.[0] ? String(stores[0].id) : "" });
    setOpen(true);
  }

  function openEdit(c: NonNullable<typeof costs>[0]) {
    setEditId(c.id);
    setForm({
      storeId: String(c.storeId),
      type: c.type,
      description: c.description,
      amount: String(c.amount),
      month: String(c.month),
      year: String(c.year),
    });
    setOpen(true);
  }

  function invalidate() {
    qc.invalidateQueries({ queryKey: getListCostsQueryKey() });
  }

  async function handleSubmit() {
    const payload = {
      storeId: parseInt(form.storeId),
      type: form.type as "shipping" | "packaging" | "other",
      description: form.description,
      amount: parseFloat(form.amount) || 0,
      month: parseInt(form.month),
      year: parseInt(form.year),
    };
    if (editId) {
      await updateCost.mutateAsync({ id: editId, data: payload });
      toast({ title: "Cost updated" });
    } else {
      await createCost.mutateAsync({ data: payload });
      toast({ title: "Cost added" });
    }
    invalidate();
    setOpen(false);
  }

  async function handleDelete() {
    if (!deleteId) return;
    await deleteCost.mutateAsync({ id: deleteId });
    toast({ title: "Cost deleted" });
    invalidate();
    setDeleteId(null);
  }

  const totalAmount = costs?.reduce((sum, c) => sum + Number(c.amount), 0) ?? 0;

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">Costs</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Track shipping, packaging and other expenses</p>
        </div>
        <Button data-testid="button-add-cost" size="sm" onClick={openCreate}>
          <Plus className="w-4 h-4 mr-1" /> Add Cost
        </Button>
      </div>

      <div className="flex flex-wrap gap-2">
        <Select value={filterStore} onValueChange={setFilterStore}>
          <SelectTrigger data-testid="select-filter-cost-store" className="h-8 w-36 text-sm"><SelectValue placeholder="All Stores" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Stores</SelectItem>
            {stores?.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger data-testid="select-filter-cost-type" className="h-8 w-32 text-sm"><SelectValue placeholder="All Types" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="shipping">Shipping</SelectItem>
            <SelectItem value="packaging">Packaging</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterMonth} onValueChange={setFilterMonth}>
          <SelectTrigger data-testid="select-filter-cost-month" className="h-8 w-28 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Months</SelectItem>
            {MONTHS.map(m => <SelectItem key={m} value={String(m)}>{monthName(m)}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterYear} onValueChange={setFilterYear}>
          <SelectTrigger data-testid="select-filter-cost-year" className="h-8 w-24 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {[NOW.getFullYear(), NOW.getFullYear() - 1, NOW.getFullYear() - 2].map(y => (
              <SelectItem key={y} value={String(y)}>{y}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        {costs && costs.length > 0 && (
          <div className="ml-auto text-sm font-semibold tabular-nums flex items-center gap-1">
            Total: <span className="text-destructive">{formatPKR(totalAmount)}</span>
          </div>
        )}
      </div>

      <div className="border rounded-md overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 border-b">
            <tr>
              {["Store", "Type", "Description", "Period", "Amount", ""].map(h => (
                <th key={h} className="text-left px-3 py-2.5 font-medium text-xs text-muted-foreground">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i} className="border-b">
                  {Array.from({ length: 6 }).map((_, j) => (
                    <td key={j} className="px-3 py-2"><Skeleton className="h-4 w-full" /></td>
                  ))}
                </tr>
              ))
            ) : !costs?.length ? (
              <tr>
                <td colSpan={6} className="text-center py-12 text-sm text-muted-foreground">
                  <DollarSign className="w-8 h-8 mx-auto mb-2 text-muted-foreground/50" />
                  No costs recorded yet.
                </td>
              </tr>
            ) : (
              costs.map(c => (
                <tr key={c.id} data-testid={`row-cost-${c.id}`} className="border-b hover:bg-muted/30 transition-colors">
                  <td className="px-3 py-2 text-xs font-medium">{c.storeName}</td>
                  <td className="px-3 py-2">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium capitalize ${TYPE_COLORS[c.type] ?? ""}`}>
                      {c.type}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-xs">{c.description}</td>
                  <td className="px-3 py-2 text-xs text-muted-foreground">{monthName(c.month)} {c.year}</td>
                  <td className="px-3 py-2 tabular-nums font-medium text-xs text-destructive">{formatPKR(Number(c.amount))}</td>
                  <td className="px-3 py-2">
                    <div className="flex gap-1">
                      <Button data-testid={`button-edit-cost-${c.id}`} variant="ghost" size="icon" className="h-6 w-6" onClick={() => openEdit(c)}>
                        <Pencil className="w-3 h-3" />
                      </Button>
                      <Button data-testid={`button-delete-cost-${c.id}`} variant="ghost" size="icon" className="h-6 w-6 text-destructive" onClick={() => setDeleteId(c.id)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editId ? "Edit Cost" : "Add Cost"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <Label>Store</Label>
              <Select value={form.storeId} onValueChange={v => setField("storeId", v)}>
                <SelectTrigger data-testid="select-cost-store"><SelectValue placeholder="Select store" /></SelectTrigger>
                <SelectContent>
                  {stores?.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type</Label>
                <Select value={form.type} onValueChange={v => setField("type", v)}>
                  <SelectTrigger data-testid="select-cost-type"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="shipping">Shipping</SelectItem>
                    <SelectItem value="packaging">Packaging</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Amount (PKR)</Label>
                <Input data-testid="input-cost-amount" type="number" value={form.amount} onChange={e => setField("amount", e.target.value)} />
              </div>
            </div>
            <div>
              <Label>Description</Label>
              <Input data-testid="input-cost-description" value={form.description} onChange={e => setField("description", e.target.value)} placeholder="e.g. PostEx bulk charges" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Month</Label>
                <Select value={form.month} onValueChange={v => setField("month", v)}>
                  <SelectTrigger data-testid="select-cost-month"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {MONTHS.map(m => <SelectItem key={m} value={String(m)}>{monthName(m)}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Year</Label>
                <Select value={form.year} onValueChange={v => setField("year", v)}>
                  <SelectTrigger data-testid="select-cost-year"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {[NOW.getFullYear(), NOW.getFullYear() - 1, NOW.getFullYear() - 2].map(y => (
                      <SelectItem key={y} value={String(y)}>{y}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button data-testid="button-cancel-cost" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button data-testid="button-save-cost" onClick={handleSubmit}
              disabled={!form.storeId || !form.description || !form.amount || createCost.isPending || updateCost.isPending}>
              {(createCost.isPending || updateCost.isPending) ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Cost?</AlertDialogTitle>
            <AlertDialogDescription>This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
