import { useState, useEffect } from "react";
import { useUser } from "@clerk/react";
import {
  TrendingUp, CheckCircle, XCircle, Clock, Users, DollarSign,
  Settings, Copy, Save, Lock, Eye, EyeOff, Gift, MessageSquare, Send, Phone,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type Sub = {
  id: number;
  clerkUserId: string;
  userName: string | null;
  userEmail: string | null;
  amount: string;
  paymentMethod: string;
  transactionId: string;
  senderName: string | null;
  senderNumber: string | null;
  status: string;
  rejectionReason: string | null;
  approvedAt: string | null;
  createdAt: string;
};

type PaymentSettings = {
  easypaisaNumber: string;
  bankName: string;
  bankAccount: string;
  bankTitle: string;
  bankIban: string;
};

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700 border-yellow-300",
  active: "bg-emerald-100 text-emerald-700 border-emerald-300",
  rejected: "bg-red-100 text-red-700 border-red-300",
};

const SESSION_KEY = "ecom_admin_verified";

export default function Admin() {
  const { user } = useUser();
  const { toast } = useToast();

  const [verified, setVerified] = useState(() => sessionStorage.getItem(SESSION_KEY) === "1");
  const [keyInput, setKeyInput] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [keyError, setKeyError] = useState("");

  const [subs, setSubs] = useState<Sub[]>([]);
  const [settings, setSettings] = useState<PaymentSettings>({
    easypaisaNumber: "03152563802",
    bankName: "",
    bankAccount: "",
    bankTitle: "",
    bankIban: "",
  });
  const [loading, setLoading] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);
  const [activeTab, setActiveTab] = useState<"payments" | "settings" | "referrals" | "broadcast">("payments");
  const [referralStats, setReferralStats] = useState<{ leaderboard: { code: string; total: number; activated: number }[]; totalWithReferral: number } | null>(null);
  const [rejectId, setRejectId] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [broadcastClients, setBroadcastClients] = useState<{ id: number; name: string; email: string | null; phone: string | null }[]>([]);
  const [broadcastMsg, setBroadcastMsg] = useState("");
  const [copiedNumbers, setCopiedNumbers] = useState(false);

  useEffect(() => {
    if (verified) loadData();
  }, [verified]);

  async function handleVerify(e: React.FormEvent) {
    e.preventDefault();
    setVerifying(true);
    setKeyError("");
    try {
      const res = await fetch("/api/admin/verify-key", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: keyInput.trim() }),
      });
      if (res.ok) {
        sessionStorage.setItem(SESSION_KEY, "1");
        setVerified(true);
      } else {
        setKeyError("Wrong key. Try again.");
      }
    } catch {
      setKeyError("Connection error. Try again.");
    } finally {
      setVerifying(false);
    }
  }

  async function loadData() {
    setLoading(true);
    try {
      const [subsRes, settingsRes, referralRes, broadcastRes] = await Promise.all([
        fetch("/api/subscriptions/admin", { credentials: "include" }),
        fetch("/api/settings/payment", { credentials: "include" }),
        fetch("/api/referrals/admin", { credentials: "include" }),
        fetch("/api/broadcast/clients", { credentials: "include" }),
      ]);
      if (subsRes.ok) setSubs(await subsRes.json());
      if (settingsRes.ok) setSettings(await settingsRes.json());
      if (referralRes.ok) setReferralStats(await referralRes.json());
      if (broadcastRes.ok) setBroadcastClients(await broadcastRes.json());
    } finally {
      setLoading(false);
    }
  }

  async function handleApprove(id: number) {
    const res = await fetch(`/api/subscriptions/${id}/approve`, {
      method: "PUT",
      credentials: "include",
    });
    if (res.ok) {
      toast({ title: "Payment approved — user now has access" });
      loadData();
    } else {
      toast({ title: "Failed to approve", variant: "destructive" });
    }
  }

  async function handleReject(id: number) {
    const res = await fetch(`/api/subscriptions/${id}/reject`, {
      method: "PUT",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason: rejectReason || "Payment not verified" }),
    });
    if (res.ok) {
      toast({ title: "Payment rejected" });
      setRejectId(null);
      setRejectReason("");
      loadData();
    }
  }

  async function handleSaveSettings() {
    setSavingSettings(true);
    try {
      const res = await fetch("/api/settings/payment", {
        method: "PUT",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      if (res.ok) {
        toast({ title: "Payment details saved" });
      } else {
        throw new Error("Failed");
      }
    } catch {
      toast({ title: "Failed to save settings", variant: "destructive" });
    } finally {
      setSavingSettings(false);
    }
  }

  // ── Key unlock screen ──────────────────────────────────────────────────────
  if (!verified) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex items-center justify-center px-4">
        <Card className="w-full max-w-sm">
          <CardContent className="pt-8 pb-8">
            <div className="flex flex-col items-center mb-6">
              <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center mb-3">
                <Lock className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-lg font-bold text-slate-900">Admin Access</h2>
              <p className="text-xs text-slate-500 mt-1">Enter your secret key to continue</p>
            </div>
            <form onSubmit={handleVerify} className="space-y-3">
              <div className="relative">
                <Input
                  type={showKey ? "text" : "password"}
                  value={keyInput}
                  onChange={e => { setKeyInput(e.target.value); setKeyError(""); }}
                  placeholder="ecom-xxxx-xxxx"
                  className={cn("pr-10 font-mono", keyError && "border-red-400")}
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setShowKey(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {keyError && <p className="text-xs text-red-500">{keyError}</p>}
              <Button type="submit" className="w-full bg-slate-900 text-white" disabled={verifying || !keyInput}>
                {verifying ? "Verifying..." : "Unlock Admin Panel"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  // ── Admin panel ────────────────────────────────────────────────────────────
  const pending = subs.filter(s => s.status === "pending");
  const active = subs.filter(s => s.status === "active");
  const totalRevenue = active.length * 499;

  return (
    <div className="min-h-screen bg-[#f8fafc]">
      <nav className="flex items-center justify-between px-6 py-4 border-b bg-white">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-emerald-500" />
          <span className="font-bold text-slate-900">EcomProfit</span>
          <Badge className="ml-1 text-xs bg-violet-100 text-violet-700 border-violet-300">Admin</Badge>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">{user?.emailAddresses?.[0]?.emailAddress}</span>
          <button
            onClick={() => { sessionStorage.removeItem(SESSION_KEY); setVerified(false); }}
            className="text-xs text-slate-400 hover:text-red-500 transition-colors"
            title="Lock admin panel"
          >
            <Lock className="w-3.5 h-3.5" />
          </button>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6">
          <h1 className="text-xl font-bold text-slate-900">Admin Panel</h1>
          <p className="text-sm text-slate-500 mt-0.5">Manage payments and account settings</p>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center gap-2 text-yellow-600 mb-1">
                <Clock className="w-4 h-4" />
                <span className="text-xs font-semibold uppercase">Pending</span>
              </div>
              <p className="text-2xl font-bold text-slate-900">{pending.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center gap-2 text-emerald-600 mb-1">
                <Users className="w-4 h-4" />
                <span className="text-xs font-semibold uppercase">Active Users</span>
              </div>
              <p className="text-2xl font-bold text-slate-900">{active.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center gap-2 text-slate-600 mb-1">
                <DollarSign className="w-4 h-4" />
                <span className="text-xs font-semibold uppercase">Total Revenue</span>
              </div>
              <p className="text-2xl font-bold text-slate-900">Rs {totalRevenue.toLocaleString()}</p>
            </CardContent>
          </Card>
        </div>

        <div className="flex gap-2 mb-5">
          <button
            onClick={() => setActiveTab("payments")}
            className={cn("px-4 py-2 text-sm font-medium rounded-lg transition-colors",
              activeTab === "payments" ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100"
            )}
          >
            Payments{pending.length > 0 && (
              <span className="ml-1.5 bg-yellow-500 text-white text-xs px-1.5 py-0.5 rounded-full">{pending.length}</span>
            )}
          </button>
          <button
            onClick={() => setActiveTab("settings")}
            className={cn("px-4 py-2 text-sm font-medium rounded-lg transition-colors flex items-center gap-1.5",
              activeTab === "settings" ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100"
            )}
          >
            <Settings className="w-3.5 h-3.5" /> Payment Details
          </button>
          <button
            onClick={() => setActiveTab("referrals")}
            className={cn("px-4 py-2 text-sm font-medium rounded-lg transition-colors flex items-center gap-1.5",
              activeTab === "referrals" ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100"
            )}
          >
            <Gift className="w-3.5 h-3.5" /> Referrals
            {referralStats && referralStats.totalWithReferral > 0 && (
              <span className="ml-0.5 bg-violet-500 text-white text-xs px-1.5 py-0.5 rounded-full">{referralStats.totalWithReferral}</span>
            )}
          </button>
          <button
            onClick={() => setActiveTab("broadcast")}
            className={cn("px-4 py-2 text-sm font-medium rounded-lg transition-colors flex items-center gap-1.5",
              activeTab === "broadcast" ? "bg-emerald-600 text-white" : "text-slate-600 hover:bg-slate-100"
            )}
          >
            <MessageSquare className="w-3.5 h-3.5" /> Broadcast
            {broadcastClients.length > 0 && (
              <span className={cn("ml-0.5 text-xs px-1.5 py-0.5 rounded-full", activeTab === "broadcast" ? "bg-white text-emerald-700" : "bg-emerald-100 text-emerald-700")}>{broadcastClients.length}</span>
            )}
          </button>
        </div>

        {activeTab === "payments" && (
          <div className="space-y-3">
            {loading ? (
              <p className="text-sm text-slate-400 text-center py-8">Loading...</p>
            ) : subs.length === 0 ? (
              <Card><CardContent className="py-12 text-center text-sm text-slate-400">No payment submissions yet</CardContent></Card>
            ) : (
              subs.map(sub => (
                <Card key={sub.id} className={cn("border", sub.status === "pending" && "border-yellow-200")}>
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="font-semibold text-sm text-slate-900">
                            {sub.userName ?? sub.senderName ?? "Unknown"}
                          </span>
                          <Badge variant="outline" className={cn("text-xs", STATUS_COLORS[sub.status])}>
                            {sub.status === "active" ? "Approved" : sub.status.charAt(0).toUpperCase() + sub.status.slice(1)}
                          </Badge>
                          <Badge variant="outline" className="text-xs capitalize">
                            {sub.paymentMethod === "easypaisa" ? "Easypaisa" : "Bank"}
                          </Badge>
                        </div>
                        {sub.userEmail && <p className="text-xs text-slate-500 mb-1">{sub.userEmail}</p>}
                        <div className="flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-slate-500">
                          <span>TXN: <span className="font-mono text-slate-700">{sub.transactionId}</span></span>
                          {sub.senderNumber && <span>Phone: {sub.senderNumber}</span>}
                          <span>Rs {sub.amount}</span>
                          <span>{new Date(sub.createdAt).toLocaleDateString("en-PK")}</span>
                        </div>
                        {sub.status === "rejected" && sub.rejectionReason && (
                          <p className="text-xs text-red-500 mt-1">Rejected: {sub.rejectionReason}</p>
                        )}
                      </div>
                      {sub.status === "pending" && (
                        <div className="flex flex-col gap-2 flex-shrink-0">
                          <Button
                            size="sm"
                            className="bg-emerald-600 hover:bg-emerald-700 text-white gap-1 text-xs"
                            onClick={() => handleApprove(sub.id)}
                          >
                            <CheckCircle className="w-3.5 h-3.5" /> Approve
                          </Button>
                          {rejectId === sub.id ? (
                            <div className="flex flex-col gap-1.5">
                              <Input
                                placeholder="Rejection reason..."
                                value={rejectReason}
                                onChange={e => setRejectReason(e.target.value)}
                                className="text-xs h-7 w-44"
                              />
                              <div className="flex gap-1">
                                <Button size="sm" variant="destructive" className="flex-1 text-xs h-7"
                                  onClick={() => handleReject(sub.id)}>Reject</Button>
                                <Button size="sm" variant="outline" className="text-xs h-7"
                                  onClick={() => setRejectId(null)}>Cancel</Button>
                              </div>
                            </div>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-xs text-red-600 border-red-200 hover:bg-red-50 gap-1"
                              onClick={() => setRejectId(sub.id)}
                            >
                              <XCircle className="w-3.5 h-3.5" /> Reject
                            </Button>
                          )}
                        </div>
                      )}
                      {sub.status === "active" && (
                        <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}

        {activeTab === "settings" && (
          <Card>
            <CardHeader><CardTitle className="text-base">Payment Account Details</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-xs text-slate-600">Easypaisa Number</Label>
                <Input
                  value={settings.easypaisaNumber}
                  onChange={e => setSettings({ ...settings, easypaisaNumber: e.target.value })}
                  placeholder="03XXXXXXXXX"
                  className="mt-1 font-mono"
                />
              </div>
              <div className="border-t pt-4">
                <p className="text-xs font-semibold text-slate-600 mb-3 uppercase tracking-wide">Bank Account Details</p>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs text-slate-600">Account Title</Label>
                      <Input value={settings.bankTitle} onChange={e => setSettings({ ...settings, bankTitle: e.target.value })} placeholder="Muhammad Ali" className="mt-1" />
                    </div>
                    <div>
                      <Label className="text-xs text-slate-600">Bank Name</Label>
                      <Input value={settings.bankName} onChange={e => setSettings({ ...settings, bankName: e.target.value })} placeholder="HBL / Meezan / UBL..." className="mt-1" />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-600">Account Number</Label>
                    <Input value={settings.bankAccount} onChange={e => setSettings({ ...settings, bankAccount: e.target.value })} placeholder="XXXXXXXXXXXXXXXX" className="mt-1 font-mono" />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-600">IBAN (optional)</Label>
                    <Input value={settings.bankIban} onChange={e => setSettings({ ...settings, bankIban: e.target.value })} placeholder="PK36XXXX0000000000000000" className="mt-1 font-mono" />
                  </div>
                </div>
              </div>
              <Button onClick={handleSaveSettings} disabled={savingSettings} className="gap-2 bg-slate-900 text-white">
                <Save className="w-4 h-4" />
                {savingSettings ? "Saving..." : "Save Payment Details"}
              </Button>
            </CardContent>
          </Card>
        )}

        {activeTab === "referrals" && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="pt-5 pb-4">
                  <div className="flex items-center gap-2 text-violet-600 mb-1">
                    <Gift className="w-4 h-4" />
                    <span className="text-xs font-semibold uppercase">Total with Referral</span>
                  </div>
                  <p className="text-2xl font-bold text-slate-900">{referralStats?.totalWithReferral ?? 0}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-5 pb-4">
                  <div className="flex items-center gap-2 text-emerald-600 mb-1">
                    <Users className="w-4 h-4" />
                    <span className="text-xs font-semibold uppercase">Top Referrers</span>
                  </div>
                  <p className="text-2xl font-bold text-slate-900">{referralStats?.leaderboard.length ?? 0}</p>
                </CardContent>
              </Card>
            </div>

            {!referralStats || referralStats.leaderboard.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-sm text-slate-400">
                  No referrals yet. Clients who refer others will appear here.
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader><CardTitle className="text-base">Referral Leaderboard</CardTitle></CardHeader>
                <CardContent className="pb-4">
                  <div className="space-y-2">
                    {referralStats.leaderboard.map((entry, i) => (
                      <div key={entry.code} className="flex items-center justify-between py-2 px-3 bg-slate-50 rounded-lg border">
                        <div className="flex items-center gap-3">
                          <span className="text-xs font-bold text-slate-400 w-5">#{i + 1}</span>
                          <div>
                            <p className="text-xs font-mono font-bold text-violet-700">{entry.code}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs">
                          <span className="text-slate-500">{entry.total} referred</span>
                          <span className="font-semibold text-emerald-600">{entry.activated} activated</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {activeTab === "broadcast" && (
          <div className="space-y-4">
            {/* Message Composer */}
            <Card className="border-emerald-200">
              <CardHeader className="pb-2 pt-4">
                <CardTitle className="text-base flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-emerald-600" />
                  Compose Message
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <textarea
                  value={broadcastMsg}
                  onChange={e => setBroadcastMsg(e.target.value)}
                  placeholder="Type your message here... e.g. 'Assalam o Alaikum! EcomProfit main naya feature aa gaya hai - ab aap apni returns bhi track kar saktay hain. Dashboard mein check karein!'"
                  rows={4}
                  className="w-full text-sm border rounded-lg px-3 py-2.5 resize-none focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>{broadcastMsg.length} characters</span>
                  <span>{broadcastClients.filter(c => c.phone).length} of {broadcastClients.length} clients have phone numbers</span>
                </div>
              </CardContent>
            </Card>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-3">
              <Card>
                <CardContent className="pt-4 pb-4 text-center">
                  <p className="text-2xl font-bold text-slate-900">{broadcastClients.length}</p>
                  <p className="text-xs text-slate-500 mt-0.5">Active Clients</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 pb-4 text-center">
                  <p className="text-2xl font-bold text-emerald-600">{broadcastClients.filter(c => c.phone).length}</p>
                  <p className="text-xs text-slate-500 mt-0.5">With Phone</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 pb-4 text-center">
                  <p className="text-2xl font-bold text-slate-400">{broadcastClients.filter(c => !c.phone).length}</p>
                  <p className="text-xs text-slate-500 mt-0.5">No Phone</p>
                </CardContent>
              </Card>
            </div>

            {/* Bulk actions */}
            {broadcastClients.filter(c => c.phone).length > 0 && (
              <Card>
                <CardContent className="pt-4 pb-4">
                  <p className="text-xs font-semibold text-slate-600 mb-3 uppercase tracking-wide">Quick Actions</p>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-1.5 text-xs"
                      onClick={() => {
                        const numbers = broadcastClients
                          .filter(c => c.phone)
                          .map(c => c.phone!.replace(/\D/g, ""))
                          .join(", ");
                        navigator.clipboard.writeText(numbers);
                        setCopiedNumbers(true);
                        setTimeout(() => setCopiedNumbers(false), 2000);
                        toast({ title: "All phone numbers copied! Paste into WhatsApp Broadcast list." });
                      }}
                    >
                      {copiedNumbers ? <CheckCircle className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                      Copy All Numbers
                    </Button>
                    {broadcastMsg.trim() && (
                      <a
                        href={`https://web.whatsapp.com/`}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Button size="sm" className="gap-1.5 text-xs bg-[#25D366] hover:bg-[#1ebe5d] text-white">
                          <Send className="w-3.5 h-3.5" />
                          Open WhatsApp Web
                        </Button>
                      </a>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 mt-2">
                    Tip: Copy all numbers → Open WhatsApp → Create Broadcast List → Paste numbers → Send your message
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Client list */}
            {broadcastClients.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-sm text-slate-400">
                  No active clients yet. Approve payments first.
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader className="pb-2 pt-4">
                  <CardTitle className="text-sm font-semibold">Active Clients</CardTitle>
                </CardHeader>
                <CardContent className="pb-4">
                  <div className="space-y-2">
                    {broadcastClients.map(client => (
                      <div key={client.id} className="flex items-center justify-between py-2 px-3 bg-slate-50 rounded-lg border">
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium text-slate-800 truncate">{client.name}</p>
                          {client.email && <p className="text-xs text-slate-400 truncate">{client.email}</p>}
                        </div>
                        {client.phone ? (
                          <div className="flex items-center gap-2 flex-shrink-0 ml-3">
                            <span className="text-xs font-mono text-slate-600">{client.phone}</span>
                            {broadcastMsg.trim() ? (
                              <a
                                href={`https://wa.me/${client.phone.replace(/\D/g, "").replace(/^0/, "92")}?text=${encodeURIComponent(broadcastMsg)}`}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                <Button size="sm" className="h-7 text-xs gap-1 bg-[#25D366] hover:bg-[#1ebe5d] text-white px-2">
                                  <Send className="w-3 h-3" /> Send
                                </Button>
                              </a>
                            ) : (
                              <a
                                href={`https://wa.me/${client.phone.replace(/\D/g, "").replace(/^0/, "92")}`}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                <Button size="sm" variant="outline" className="h-7 text-xs gap-1 px-2">
                                  <Phone className="w-3 h-3" /> Chat
                                </Button>
                              </a>
                            )}
                          </div>
                        ) : (
                          <span className="text-xs text-slate-300 flex-shrink-0 ml-3">No phone</span>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        <div className="mt-6 p-4 bg-slate-100 rounded-xl">
          <p className="text-xs text-slate-500 font-semibold mb-1">Your Clerk User ID:</p>
          <div className="flex items-center gap-2">
            <code className="text-xs font-mono text-slate-700 bg-white px-2 py-1 rounded border flex-1 truncate">
              {user?.id ?? "Loading..."}
            </code>
            <button
              onClick={() => { navigator.clipboard.writeText(user?.id ?? ""); toast({ title: "User ID copied" }); }}
              className="text-slate-400 hover:text-slate-600"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
