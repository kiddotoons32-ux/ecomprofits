import { useState } from "react";
import { RefreshCw, CheckCircle, XCircle, AlertCircle, Eye, EyeOff, Zap, ShoppingBag, Package } from "lucide-react";
import {
  useListStores,
  useSyncShopifyOrders,
  useSyncPostexStatuses,
  useSaveStoreIntegrations,
  getListStoresQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type SyncResult = {
  imported?: number;
  skipped?: number;
  updated?: number;
  total?: number;
  message?: string | null;
  errors?: string[];
};

type StoreCredentials = {
  shopifyApiToken: string;
  postexApiKey: string;
};

export default function Integrations() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: stores, isLoading } = useListStores();
  const syncShopify = useSyncShopifyOrders();
  const syncPostex = useSyncPostexStatuses();
  const saveCreds = useSaveStoreIntegrations();

  const [credentials, setCredentials] = useState<Record<number, StoreCredentials>>({});
  const [showTokens, setShowTokens] = useState<Record<string, boolean>>({});
  const [syncResults, setSyncResults] = useState<Record<string, SyncResult>>({});
  const [savingId, setSavingId] = useState<number | null>(null);
  const [syncingKey, setSyncingKey] = useState<string | null>(null);

  function getCreds(storeId: number): StoreCredentials {
    return credentials[storeId] ?? { shopifyApiToken: "", postexApiKey: "" };
  }

  function updateCred(storeId: number, key: keyof StoreCredentials, value: string) {
    setCredentials(prev => ({
      ...prev,
      [storeId]: { ...getCreds(storeId), [key]: value },
    }));
  }

  function toggleShow(key: string) {
    setShowTokens(prev => ({ ...prev, [key]: !prev[key] }));
  }

  async function handleSaveCreds(storeId: number) {
    setSavingId(storeId);
    try {
      const creds = getCreds(storeId);
      await saveCreds.mutateAsync({
        id: storeId,
        data: {
          shopifyApiToken: creds.shopifyApiToken || null,
          postexApiKey: creds.postexApiKey || null,
        },
      });
      qc.invalidateQueries({ queryKey: getListStoresQueryKey() });
      toast({ title: "Credentials saved" });
    } catch (err: any) {
      toast({ title: "Error saving credentials", description: err.message, variant: "destructive" });
    } finally {
      setSavingId(null);
    }
  }

  async function handleSyncShopify(storeId: number) {
    const key = `shopify-${storeId}`;
    setSyncingKey(key);
    try {
      const result = await syncShopify.mutateAsync({ id: storeId });
      setSyncResults(prev => ({ ...prev, [key]: result }));
      qc.invalidateQueries({ queryKey: getListStoresQueryKey() });
      toast({
        title: `Shopify sync complete`,
        description: `${result.imported ?? 0} imported, ${result.skipped ?? 0} skipped`,
      });
    } catch (err: any) {
      const msg = err?.response?.data?.error ?? err.message;
      setSyncResults(prev => ({ ...prev, [key]: { errors: [msg] } }));
      toast({ title: "Shopify sync failed", description: msg, variant: "destructive" });
    } finally {
      setSyncingKey(null);
    }
  }

  async function handleSyncPostex(storeId: number) {
    const key = `postex-${storeId}`;
    setSyncingKey(key);
    try {
      const result = await syncPostex.mutateAsync({ id: storeId });
      setSyncResults(prev => ({ ...prev, [key]: result }));
      toast({
        title: `PostEx sync complete`,
        description: result.message ?? `${result.updated ?? 0} orders updated`,
      });
    } catch (err: any) {
      const msg = err?.response?.data?.error ?? err.message;
      setSyncResults(prev => ({ ...prev, [key]: { errors: [msg] } }));
      toast({ title: "PostEx sync failed", description: msg, variant: "destructive" });
    } finally {
      setSyncingKey(null);
    }
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-xl font-bold">Integrations</h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          Connect your Shopify stores and PostEx courier account to sync data automatically
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-2">
        <IntegrationInfoCard
          icon={<ShoppingBag className="w-5 h-5 text-green-600" />}
          color="bg-green-50 border-green-200"
          title="Shopify"
          description="Pull orders directly from your Shopify Admin API. Orders are imported once and skipped on re-sync."
          steps={[
            "Go to Shopify Admin → Settings → Apps and sales channels → Develop apps",
            "Create a private app, grant Orders read permission",
            "Copy the Admin API access token",
          ]}
        />
        <IntegrationInfoCard
          icon={<Package className="w-5 h-5 text-blue-600" />}
          color="bg-blue-50 border-blue-200"
          title="PostEx"
          description="Sync delivery/return statuses for PostEx shipments. Only orders with courier set to PostEx and a tracking number are updated."
          steps={[
            "Log into PostEx merchant portal",
            "Go to API Settings and copy your API token",
            "Make sure orders have courier = PostEx and a tracking number",
          ]}
        />
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2].map(i => <Skeleton key={i} className="h-64" />)}
        </div>
      ) : !stores?.length ? (
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            No stores found. Add a store first from the Stores page.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-5">
          {stores.map(store => {
            const creds = getCreds(store.id);
            const shopifyKey = `shopify-${store.id}`;
            const postexKey = `postex-${store.id}`;
            const isShopify = store.platform === "shopify";
            const isSyncingShopify = syncingKey === shopifyKey;
            const isSyncingPostex = syncingKey === postexKey;
            const isSaving = savingId === store.id;

            const hasShopifyToken = !!(creds.shopifyApiToken || store.shopifyApiToken);
            const hasPostexKey = !!(creds.postexApiKey || store.postexApiKey);

            return (
              <Card key={store.id} className="overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-base">{store.name}</CardTitle>
                      <Badge variant="secondary" className="text-xs capitalize">{store.platform}</Badge>
                      {store.clientName && (
                        <span className="text-xs text-muted-foreground">· {store.clientName}</span>
                      )}
                    </div>
                    <Badge variant={store.isActive ? "default" : "secondary"} className="text-xs">
                      {store.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {isShopify && (
                      <div className="space-y-3 border rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-1">
                          <ShoppingBag className="w-4 h-4 text-green-600" />
                          <span className="text-sm font-semibold">Shopify</span>
                          {store.shopifyApiToken && (
                            <Badge variant="outline" className="text-xs text-green-600 border-green-300 gap-1">
                              <CheckCircle className="w-3 h-3" /> Connected
                            </Badge>
                          )}
                        </div>
                        {store.shopifyDomain && (
                          <p className="text-xs text-muted-foreground">{store.shopifyDomain}</p>
                        )}
                        <div>
                          <Label className="text-xs">Admin API Access Token</Label>
                          <div className="relative mt-1">
                            <Input
                              type={showTokens[`st-${store.id}`] ? "text" : "password"}
                              placeholder={store.shopifyApiToken ? "••••••••••••••••" : "shpat_xxxxxxxxxxxxxxxx"}
                              value={creds.shopifyApiToken}
                              onChange={e => updateCred(store.id, "shopifyApiToken", e.target.value)}
                              className="pr-9 text-xs font-mono"
                            />
                            <button
                              type="button"
                              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                              onClick={() => toggleShow(`st-${store.id}`)}
                            >
                              {showTokens[`st-${store.id}`] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="flex-1 text-xs"
                            onClick={() => handleSaveCreds(store.id)}
                            disabled={isSaving}
                          >
                            {isSaving ? "Saving..." : "Save Token"}
                          </Button>
                          <Button
                            size="sm"
                            className="flex-1 text-xs gap-1 bg-green-600 hover:bg-green-700"
                            onClick={() => handleSyncShopify(store.id)}
                            disabled={isSyncingShopify || !hasShopifyToken}
                          >
                            <RefreshCw className={cn("w-3 h-3", isSyncingShopify && "animate-spin")} />
                            {isSyncingShopify ? "Syncing..." : "Sync Orders"}
                          </Button>
                        </div>
                        <SyncResultBadge result={syncResults[shopifyKey]} />
                      </div>
                    )}

                    <div className="space-y-3 border rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-1">
                        <Package className="w-4 h-4 text-blue-600" />
                        <span className="text-sm font-semibold">PostEx</span>
                        {store.postexApiKey && (
                          <Badge variant="outline" className="text-xs text-blue-600 border-blue-300 gap-1">
                            <CheckCircle className="w-3 h-3" /> Connected
                          </Badge>
                        )}
                      </div>
                      <div>
                        <Label className="text-xs">PostEx API Key</Label>
                        <div className="relative mt-1">
                          <Input
                            type={showTokens[`px-${store.id}`] ? "text" : "password"}
                            placeholder={store.postexApiKey ? "••••••••••••••••" : "Your PostEx API token"}
                            value={creds.postexApiKey}
                            onChange={e => updateCred(store.id, "postexApiKey", e.target.value)}
                            className="pr-9 text-xs font-mono"
                          />
                          <button
                            type="button"
                            className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                            onClick={() => toggleShow(`px-${store.id}`)}
                          >
                            {showTokens[`px-${store.id}`] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 text-xs"
                          onClick={() => handleSaveCreds(store.id)}
                          disabled={isSaving}
                        >
                          {isSaving ? "Saving..." : "Save Key"}
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 text-xs gap-1 bg-blue-600 hover:bg-blue-700"
                          onClick={() => handleSyncPostex(store.id)}
                          disabled={isSyncingPostex || !hasPostexKey}
                        >
                          <RefreshCw className={cn("w-3 h-3", isSyncingPostex && "animate-spin")} />
                          {isSyncingPostex ? "Syncing..." : "Sync Status"}
                        </Button>
                      </div>
                      <SyncResultBadge result={syncResults[postexKey]} />
                    </div>

                    {!isShopify && (
                      <div className="border border-dashed rounded-lg p-4 flex flex-col items-center justify-center text-center gap-2">
                        <Zap className="w-6 h-6 text-muted-foreground/40" />
                        <p className="text-xs text-muted-foreground">
                          Shopify sync is only available for Shopify stores.
                          Change the platform in Store settings.
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function IntegrationInfoCard({
  icon, color, title, description, steps,
}: {
  icon: React.ReactNode;
  color: string;
  title: string;
  description: string;
  steps: string[];
}) {
  return (
    <Card className={cn("border", color)}>
      <CardContent className="pt-4 pb-4">
        <div className="flex items-center gap-2 mb-2">
          {icon}
          <span className="font-semibold text-sm">{title}</span>
        </div>
        <p className="text-xs text-muted-foreground mb-3">{description}</p>
        <ol className="space-y-1">
          {steps.map((step, i) => (
            <li key={i} className="text-xs text-muted-foreground flex gap-2">
              <span className="font-semibold text-foreground/60 flex-shrink-0">{i + 1}.</span>
              <span>{step}</span>
            </li>
          ))}
        </ol>
      </CardContent>
    </Card>
  );
}

function SyncResultBadge({ result }: { result?: SyncResult }) {
  if (!result) return null;
  const hasErrors = result.errors && result.errors.length > 0;
  if (hasErrors) {
    return (
      <div className="text-xs text-destructive flex items-start gap-1 mt-1">
        <XCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
        <span>{result.errors![0]}</span>
      </div>
    );
  }
  const parts = [];
  if (result.imported != null) parts.push(`${result.imported} imported`);
  if (result.updated != null) parts.push(`${result.updated} updated`);
  if (result.skipped != null) parts.push(`${result.skipped} skipped`);
  if (result.message) parts.push(result.message);
  return (
    <div className="text-xs text-emerald-600 flex items-center gap-1 mt-1">
      <CheckCircle className="w-3.5 h-3.5" />
      <span>{parts.join(" · ")}</span>
    </div>
  );
}
