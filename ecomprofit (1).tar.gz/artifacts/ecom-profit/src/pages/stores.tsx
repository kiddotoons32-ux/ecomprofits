import { useState } from "react";
import { Plus, Pencil, Trash2, Store as StoreIcon, CheckCircle, XCircle } from "lucide-react";
import {
  useListStores, useCreateStore, useUpdateStore, useDeleteStore,
  getListStoresQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

type StoreForm = {
  name: string; platform: string; shopifyDomain: string;
  currency: string; clientName: string; isActive: boolean;
};

const EMPTY_FORM: StoreForm = {
  name: "", platform: "shopify", shopifyDomain: "",
  currency: "PKR", clientName: "", isActive: true,
};

const PLATFORM_LABELS: Record<string, string> = {
  shopify: "Shopify", manual: "Manual", woocommerce: "WooCommerce", other: "Other"
};

export default function Stores() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: stores, isLoading } = useListStores();
  const createStore = useCreateStore();
  const updateStore = useUpdateStore();
  const deleteStore = useDeleteStore();

  const [open, setOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<StoreForm>(EMPTY_FORM);

  function openCreate() {
    setEditId(null);
    setForm(EMPTY_FORM);
    setOpen(true);
  }

  function openEdit(store: NonNullable<typeof stores>[0]) {
    setEditId(store.id);
    setForm({
      name: store.name,
      platform: store.platform,
      shopifyDomain: store.shopifyDomain ?? "",
      currency: store.currency,
      clientName: store.clientName ?? "",
      isActive: store.isActive,
    });
    setOpen(true);
  }

  function invalidate() {
    qc.invalidateQueries({ queryKey: getListStoresQueryKey() });
  }

  async function handleSubmit() {
    const payload = {
      name: form.name,
      platform: form.platform as "shopify" | "manual" | "woocommerce" | "other",
      shopifyDomain: form.shopifyDomain || null,
      currency: form.currency,
      clientName: form.clientName || null,
      isActive: form.isActive,
    };
    if (editId) {
      await updateStore.mutateAsync({ id: editId, data: payload });
      toast({ title: "Store updated" });
    } else {
      await createStore.mutateAsync({ data: payload });
      toast({ title: "Store added" });
    }
    invalidate();
    setOpen(false);
  }

  async function handleDelete() {
    if (!deleteId) return;
    await deleteStore.mutateAsync({ id: deleteId });
    toast({ title: "Store deleted" });
    invalidate();
    setDeleteId(null);
  }

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">Stores</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage your e-commerce stores</p>
        </div>
        <Button data-testid="button-add-store" size="sm" onClick={openCreate}>
          <Plus className="w-4 h-4 mr-1" /> Add Store
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-32" />)}
        </div>
      ) : !stores?.length ? (
        <Card>
          <CardContent className="py-16 text-center">
            <StoreIcon className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
            <p className="text-sm text-muted-foreground">No stores yet. Add your first store.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {stores.map(store => (
            <Card key={store.id} data-testid={`card-store-${store.id}`}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-violet-100 rounded-md">
                      <StoreIcon className="w-5 h-5 text-violet-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-sm">{store.name}</div>
                      {store.clientName && (
                        <div className="text-xs text-muted-foreground">{store.clientName}</div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button data-testid={`button-edit-store-${store.id}`} variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(store)}>
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button data-testid={`button-delete-store-${store.id}`} variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setDeleteId(store.id)}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Badge variant="secondary">{PLATFORM_LABELS[store.platform] ?? store.platform}</Badge>
                  <Badge variant="outline">{store.currency}</Badge>
                  <Badge variant={store.isActive ? "default" : "secondary"} className="flex items-center gap-1">
                    {store.isActive ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                    {store.isActive ? "Active" : "Inactive"}
                  </Badge>
                </div>
                {store.shopifyDomain && (
                  <div className="text-xs text-muted-foreground mt-2">{store.shopifyDomain}</div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editId ? "Edit Store" : "Add Store"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <Label>Store Name</Label>
              <Input data-testid="input-store-name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="My Shopify Store" />
            </div>
            <div>
              <Label>Platform</Label>
              <Select value={form.platform} onValueChange={v => setForm({ ...form, platform: v })}>
                <SelectTrigger data-testid="select-platform"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="shopify">Shopify</SelectItem>
                  <SelectItem value="manual">Manual</SelectItem>
                  <SelectItem value="woocommerce">WooCommerce</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {form.platform === "shopify" && (
              <div>
                <Label>Shopify Domain</Label>
                <Input data-testid="input-shopify-domain" value={form.shopifyDomain} onChange={e => setForm({ ...form, shopifyDomain: e.target.value })} placeholder="store.myshopify.com" />
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Currency</Label>
                <Input data-testid="input-currency" value={form.currency} onChange={e => setForm({ ...form, currency: e.target.value })} />
              </div>
              <div>
                <Label>Client Name</Label>
                <Input data-testid="input-client-name" value={form.clientName} onChange={e => setForm({ ...form, clientName: e.target.value })} placeholder="Optional" />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="isActive" checked={form.isActive} onChange={e => setForm({ ...form, isActive: e.target.checked })} className="w-4 h-4" data-testid="checkbox-active" />
              <Label htmlFor="isActive">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button data-testid="button-cancel-store" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button data-testid="button-save-store" onClick={handleSubmit} disabled={!form.name || createStore.isPending || updateStore.isPending}>
              {(createStore.isPending || updateStore.isPending) ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Store?</AlertDialogTitle>
            <AlertDialogDescription>This will delete the store and all its orders. This cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
