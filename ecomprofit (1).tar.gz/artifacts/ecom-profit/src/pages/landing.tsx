import { Link } from "wouter";
import { TrendingUp, BarChart3, ShoppingBag, Package, ArrowRight, CheckCircle, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";

const features = [
  { icon: BarChart3, title: "Monthly P&L Reports", desc: "See exactly how much profit or loss each store made every month." },
  { icon: ShoppingBag, title: "Shopify Integration", desc: "Pull orders directly from Shopify — no manual entry needed." },
  { icon: Package, title: "Courier Sync", desc: "Auto-sync PostEx, TCS, Leopards delivery & return statuses." },
  { icon: TrendingUp, title: "6-Month Trends", desc: "Track revenue and profit trends over time with visual charts." },
];

const included = [
  "Unlimited orders & shipments",
  "Shopify + PostEx sync",
  "Monthly P&L reports",
  "6-month profit trends",
  "All courier integrations",
  "Lifetime access — no renewals",
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col">
      <nav className="flex items-center justify-between px-8 py-4 border-b bg-white">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-emerald-500" />
          <span className="font-bold text-lg text-slate-900">EcomProfit</span>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/sign-in">
            <Button variant="ghost" size="sm" className="text-slate-600">Sign In</Button>
          </Link>
          <Link href="/sign-up">
            <Button size="sm" className="bg-slate-900 hover:bg-slate-800 text-white gap-1">
              Get Started <ArrowRight className="w-3.5 h-3.5" />
            </Button>
          </Link>
        </div>
      </nav>

      <main className="flex-1">
        <section className="max-w-4xl mx-auto px-6 pt-20 pb-16 text-center">
          <div className="inline-flex items-center gap-2 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-medium px-3 py-1.5 rounded-full mb-6">
            <TrendingUp className="w-3.5 h-3.5" />
            Built for Pakistani E-commerce Sellers
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold text-slate-900 leading-tight mb-4">
            Know Your Profit.<br />
            <span className="text-emerald-600">Grow Your Business.</span>
          </h1>
          <p className="text-lg text-slate-500 max-w-xl mx-auto mb-8">
            EcomProfit tracks every order, shipment, and cost — then shows you exactly what you earned in PKR. No spreadsheets needed.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link href="/sign-up">
              <Button size="lg" className="bg-slate-900 hover:bg-slate-800 text-white px-8 gap-2">
                Start Now — Rs 499 <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Link href="/sign-in">
              <Button size="lg" variant="outline" className="px-8">
                Sign In
              </Button>
            </Link>
          </div>
        </section>

        <section className="max-w-5xl mx-auto px-6 pb-16">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {features.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="bg-white rounded-xl border p-5">
                <div className="w-9 h-9 bg-slate-100 rounded-lg flex items-center justify-center mb-3">
                  <Icon className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h3 className="font-semibold text-sm text-slate-900 mb-1">{title}</h3>
                <p className="text-xs text-slate-500 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Pricing */}
        <section className="max-w-md mx-auto px-6 pb-20">
          <div className="bg-white border-2 border-emerald-500 rounded-2xl overflow-hidden shadow-lg">
            <div className="bg-emerald-500 px-6 py-3 text-center">
              <span className="text-white text-xs font-semibold uppercase tracking-widest">One-Time Price</span>
            </div>
            <div className="px-8 py-8 text-center">
              <div className="flex items-end justify-center gap-1 mb-1">
                <span className="text-slate-500 text-lg font-medium">Rs</span>
                <span className="text-6xl font-bold text-slate-900">499</span>
              </div>
              <p className="text-slate-400 text-sm mb-6">Pay once. Use forever. No monthly fees.</p>

              <ul className="text-left space-y-2.5 mb-7">
                {included.map(item => (
                  <li key={item} className="flex items-center gap-2.5 text-sm text-slate-700">
                    <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>

              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 mb-5 flex items-center gap-2.5">
                <Smartphone className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                <div className="text-left">
                  <p className="text-xs font-semibold text-emerald-700">Pay via Easypaisa or Bank Transfer</p>
                  <p className="text-xs text-emerald-600">Instant activation after verification</p>
                </div>
              </div>

              <Link href="/sign-up">
                <Button className="w-full bg-slate-900 hover:bg-slate-800 text-white text-base py-5 gap-2">
                  Get Access Now <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <p className="text-xs text-slate-400 mt-3">Create account → Pay → Access granted within 24h</p>
            </div>
          </div>
        </section>

        <section className="bg-slate-900 py-14 text-center px-6">
          <h2 className="text-2xl font-bold text-white mb-2">Ready to see your real profits?</h2>
          <p className="text-slate-400 text-sm mb-6">Rs 499 one-time. No subscriptions. No hidden fees.</p>
          <Link href="/sign-up">
            <Button size="lg" className="bg-emerald-500 hover:bg-emerald-400 text-white px-8 gap-2">
              Get Started Now <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </section>
      </main>

      <footer className="border-t bg-white px-8 py-4 text-center text-xs text-slate-400">
        © 2026 EcomProfit — Profit & Loss Tracking for E-commerce
      </footer>
    </div>
  );
}
