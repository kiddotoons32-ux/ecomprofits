import { SignUp } from "@clerk/react";
import { TrendingUp } from "lucide-react";
import { shadcn } from "@clerk/themes";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

const appearance = {
  baseTheme: shadcn,
  cssLayerName: "clerk" as const,
  options: {
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
    logoPlacement: "inside" as const,
  },
  variables: {
    colorPrimary: "#0f172a",
    colorForeground: "#0f172a",
    colorMutedForeground: "#64748b",
    colorDanger: "#ef4444",
    colorBackground: "#ffffff",
    colorInput: "#f1f5f9",
    colorInputForeground: "#0f172a",
    colorNeutral: "#94a3b8",
    fontFamily: "Inter, sans-serif",
    borderRadius: "0.4rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-white rounded-2xl w-[420px] max-w-full overflow-hidden shadow-lg border border-slate-200",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-slate-900 font-bold",
    headerSubtitle: "text-slate-500",
    socialButtonsBlockButtonText: "text-slate-700 font-medium",
    formFieldLabel: "text-slate-700 text-sm font-medium",
    formFieldInput: "bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400",
    formButtonPrimary: "bg-slate-900 hover:bg-slate-800 text-white",
    footerActionLink: "text-emerald-600 hover:text-emerald-500 font-medium",
    footerActionText: "text-slate-500",
    dividerText: "text-slate-400",
    dividerLine: "bg-slate-200",
    identityPreviewEditButton: "text-emerald-600",
    formFieldSuccessText: "text-emerald-600",
    alertText: "text-slate-700",
    socialButtonsBlockButton: "border-slate-200 hover:bg-slate-50",
    logoBox: "flex justify-center mb-1",
    logoImage: "w-10 h-10",
    footerAction: "bg-slate-50",
    alert: "border-red-100 bg-red-50",
    otpCodeFieldInput: "border-slate-200 bg-slate-50",
    formFieldRow: "gap-3",
    main: "gap-4",
  },
};

export default function SignUpPage() {
  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-[45%] bg-slate-900 flex-col justify-between p-10">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          <span className="font-bold text-white">EcomProfit</span>
        </div>
        <div>
          <h2 className="text-3xl font-bold text-white leading-tight mb-3">
            Start tracking your<br />e-commerce profits.
          </h2>
          <p className="text-slate-400 text-sm leading-relaxed mb-8">
            Join EcomProfit and get a complete picture of your revenue, costs, and profit in PKR.
          </p>
          <div className="space-y-3">
            {["Free to get started", "Connect Shopify in minutes", "PostEx & courier sync"].map(t => (
              <div key={t} className="flex items-center gap-2 text-sm text-slate-300">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 flex-shrink-0" />
                {t}
              </div>
            ))}
          </div>
        </div>
        <p className="text-slate-600 text-xs">© 2026 EcomProfit SaaS</p>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-6 bg-[#f8fafc]">
        <div className="lg:hidden flex items-center gap-2 mb-8">
          <TrendingUp className="w-5 h-5 text-emerald-500" />
          <span className="font-bold text-slate-900">EcomProfit</span>
        </div>
        <SignUp
          routing="path"
          path={`${basePath}/sign-up`}
          signInUrl={`${basePath}/sign-in`}
          appearance={appearance}
        />
      </div>
    </div>
  );
}
