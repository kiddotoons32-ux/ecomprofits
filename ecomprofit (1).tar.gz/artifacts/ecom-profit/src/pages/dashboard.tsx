import { useState, useEffect } from "react";
import { TrendingUp, TrendingDown, ShoppingCart, CheckCircle, RotateCcw, XCircle, Store, Package, Gift, Copy, Users } from "lucide-react";
import { useGetDashboardSummary, useGetMonthlyTrends, useListStores, getGetDashboardSummaryQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { formatPKR, formatPercent } from "@/lib/format";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from "recharts";

function KpiCard({
  title, value, sub, icon: Icon, trend, color
}: {
  title: string; value: string; sub?: string;
  icon: React.ElementType; trend?: number; color: string;
}) {
  return (
    <Card data-testid={`kpi-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardContent className="pt-5 pb-4 px-5">
        <div className="flex items-start justify-between mb-3">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{title}</span>
          <div className={`p-1.5 rounded-md ${color}`}>
            <Icon className="w-4 h-4" />
          </div>
        </div>
        <div className="text-2xl font-bold tabular-nums">{value}</div>
        {(sub || trend !== undefined) && (
          <div className="flex items-center gap-1 mt-1">
            {trend !== undefined && (
              trend >= 0
                ? <TrendingUp className="w-3 h-3 text-emerald-500" />
                : <TrendingDown className="w-3 h-3 text-red-500" />
            )}
            {sub && <span className="text-xs text-muted-foreground">{sub}</span>}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

const PIE_COLORS = ["#10b981", "#ef4444", "#f59e0b", "#6366f1", "#94a3b8"];

type ReferralInfo = {
  code: string;
  totalReferred: number;
  activatedCount: number;
};

export default function Dashboard() {
  const { toast } = useToast();
  const { data: stores } = useListStores();
  const [selectedStore, setSelectedStore] = useState<string>("all");
  const [referral, setReferral] = useState<ReferralInfo | null>(null);

  useEffect(() => {
    fetch("/api/referrals/my", { credentials: "include" })
      .then(r => r.json())
      .then(setReferral)
      .catch(() => {});
  }, []);

  function copyReferralLink() {
    if (!referral) return;
    const base = window.location.origin;
    navigator.clipboard.writeText(`${base}/subscribe?ref=${referral.code}`);
    toast({ title: "Referral link copied!" });
  }

  const storeId = selectedStore !== "all" ? parseInt(selectedStore) : undefined;

  const { data: dashboard, isLoading } = useGetDashboardSummary(
    storeId ? { storeId } : {},
    { query: { queryKey: getGetDashboardSummaryQueryKey(storeId ? { storeId } : {}) } }
  );

  const { data: trends } = useGetMonthlyTrends(
    storeId ? { months: 6, storeId } : { months: 6 },
  );

  const cur = dashboard?.currentMonth;
  const prev = dashboard?.previousMonth;

  const profitTrend = prev?.netProfit && prev.netProfit !== 0
    ? ((( cur?.netProfit ?? 0) - prev.netProfit) / Math.abs(prev.netProfit)) * 100
    : 0;

  const pieData = cur ? [
    { name: "Delivered", value: cur.deliveredOrders },
    { name: "Returned", value: cur.returnedOrders },
    { name: "Not Delivered", value: cur.notDeliveredOrders },
    { name: "Pending", value: cur.pendingOrders },
    { name: "Cancelled", value: cur.cancelledOrders },
  ].filter(d => d.value > 0) : [];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Monthly performance overview</p>
        </div>
        <Select value={selectedStore} onValueChange={setSelectedStore}>
          <SelectTrigger data-testid="select-store-filter" className="w-44 h-8 text-sm">
            <SelectValue placeholder="All Stores" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Stores</SelectItem>
            {stores?.map(s => (
              <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-lg" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <KpiCard
            title="Net Profit" value={formatPKR(cur?.netProfit ?? 0)}
            icon={TrendingUp} trend={profitTrend}
            sub={`${profitTrend >= 0 ? "+" : ""}${profitTrend.toFixed(1)}% vs last month`}
            color="bg-emerald-100 text-emerald-700"
          />
          <KpiCard
            title="Revenue" value={formatPKR(cur?.totalRevenue ?? 0)}
            icon={Package} color="bg-blue-100 text-blue-700"
            sub={`Margin: ${formatPercent(cur?.profitMargin)}`}
          />
          <KpiCard
            title="Total Orders" value={String(cur?.totalOrders ?? 0)}
            icon={ShoppingCart} color="bg-violet-100 text-violet-700"
            sub={`Delivery: ${formatPercent(cur?.deliveryRate)}`}
          />
          <KpiCard
            title="Delivered" value={String(cur?.deliveredOrders ?? 0)}
            icon={CheckCircle} color="bg-emerald-100 text-emerald-700"
          />
          <KpiCard
            title="Returned" value={String(cur?.returnedOrders ?? 0)}
            icon={RotateCcw} color="bg-red-100 text-red-700"
            sub={`Return rate: ${formatPercent(cur?.returnRate)}`}
          />
          <KpiCard
            title="Not Delivered" value={String(cur?.notDeliveredOrders ?? 0)}
            icon={XCircle} color="bg-amber-100 text-amber-700"
          />
          <KpiCard
            title="Total Costs" value={formatPKR((cur?.totalShippingCost ?? 0) + (cur?.totalPackagingCost ?? 0) + (cur?.totalOtherCosts ?? 0))}
            icon={TrendingDown} color="bg-orange-100 text-orange-700"
          />
          <KpiCard
            title="Active Stores" value={String(dashboard?.totalStores ?? 0)}
            icon={Store} color="bg-slate-100 text-slate-700"
            sub={dashboard?.topStore ? `Top: ${dashboard.topStore}` : undefined}
          />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2 pt-4 px-5">
            <CardTitle className="text-sm font-semibold">Profit & Revenue Trend (6 months)</CardTitle>
          </CardHeader>
          <CardContent className="px-2 pb-4">
            {trends && trends.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={trends} margin={{ top: 4, right: 16, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
                  <Tooltip formatter={(v: number) => formatPKR(v)} />
                  <Line type="monotone" dataKey="revenue" stroke="#6366f1" strokeWidth={2} dot={false} name="Revenue" />
                  <Line type="monotone" dataKey="netProfit" stroke="#10b981" strokeWidth={2} dot={false} name="Net Profit" />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">No trend data yet</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2 pt-4 px-5">
            <CardTitle className="text-sm font-semibold">Order Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="pb-4">
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" nameKey="name">
                    {pieData.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">No orders this month</div>
            )}
          </CardContent>
        </Card>
      </div>

      {cur && (
        <Card>
          <CardHeader className="pb-2 pt-4 px-5">
            <CardTitle className="text-sm font-semibold">Cost Breakdown (This Month)</CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              {[
                { label: "Cost of Goods", value: cur.totalCostOfGoods },
                { label: "Shipping", value: cur.totalShippingCost },
                { label: "Packaging", value: cur.totalPackagingCost },
                { label: "Other", value: cur.totalOtherCosts },
              ].map(({ label, value }) => (
                <div key={label} className="border rounded-md p-3">
                  <div className="text-xs text-muted-foreground mb-1">{label}</div>
                  <div className="font-semibold tabular-nums">{formatPKR(value)}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {referral && (
        <Card className="border-violet-200 bg-gradient-to-br from-violet-50 to-white">
          <CardContent className="pt-5 pb-5 px-5">
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-violet-100 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Gift className="w-5 h-5 text-violet-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-900">Refer Friends — Earn Recognition</p>
                  <p className="text-xs text-slate-500 mt-0.5">Share your link. Every friend who joins is tracked under your name.</p>
                </div>
              </div>
              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-3 text-sm">
                  <div className="text-center">
                    <div className="text-lg font-bold text-violet-700">{referral.totalReferred}</div>
                    <div className="text-[10px] text-slate-400 uppercase tracking-wide">Referred</div>
                  </div>
                  <div className="w-px h-8 bg-slate-200" />
                  <div className="text-center">
                    <div className="text-lg font-bold text-emerald-600">{referral.activatedCount}</div>
                    <div className="text-[10px] text-slate-400 uppercase tracking-wide">Activated</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 bg-white border border-violet-200 rounded-lg px-3 py-2">
                  <Users className="w-3.5 h-3.5 text-violet-500 flex-shrink-0" />
                  <span className="font-mono text-sm font-bold text-violet-700 tracking-widest">{referral.code}</span>
                  <button
                    onClick={copyReferralLink}
                    className="text-slate-400 hover:text-violet-600 transition-colors ml-1"
                    title="Copy referral link"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
