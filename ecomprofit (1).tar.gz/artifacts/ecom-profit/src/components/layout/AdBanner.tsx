/**
 * Ad Banner — shown to users on free trial.
 * Disappears automatically when they pay Rs 499.
 *
 * TO ADD YOUR AD CODE:
 * 1. Get your Google Adsense code from adsense.google.com
 * 2. Replace the placeholder <div> below with your <ins class="adsbygoogle"...> tag
 * 3. Add the Adsense <script> tag to artifacts/ecom-profit/index.html <head>
 */

export function AdBanner() {
  return (
    <div className="w-full bg-slate-100 border-b border-slate-200 flex items-center justify-center py-2 px-4 min-h-[60px]">
      {/* ── PASTE YOUR AD CODE HERE ── */}
      <div className="flex items-center justify-center w-full max-w-3xl min-h-[50px] border-2 border-dashed border-slate-300 rounded-lg bg-white text-xs text-slate-400 gap-2">
        <span className="font-semibold uppercase tracking-wide text-slate-300">Advertisement</span>
        <span className="text-slate-200">|</span>
        <span>Paste your Google Adsense code in AdBanner.tsx</span>
      </div>
      {/* ── END AD CODE ── */}
    </div>
  );
}
