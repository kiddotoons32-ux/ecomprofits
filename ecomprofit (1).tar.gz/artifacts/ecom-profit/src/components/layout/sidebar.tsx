import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, ShoppingCart, Store, Truck, DollarSign,
  BarChart3, TrendingUp, Zap, LogOut, ShieldCheck, Clock,
} from "lucide-react";
import { useClerk, useUser } from "@clerk/react";
import { cn } from "@/lib/utils";
import { isAdminSession } from "@/App";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/orders", label: "Orders", icon: ShoppingCart },
  { href: "/stores", label: "Stores", icon: Store },
  { href: "/shipments", label: "Shipments", icon: Truck },
  { href: "/costs", label: "Costs", icon: DollarSign },
  { href: "/reports", label: "Reports", icon: BarChart3 },
  { href: "/integrations", label: "Integrations", icon: Zap },
];

interface SidebarProps {
  isTrial?: boolean;
  trialDaysLeft?: number;
}

export function Sidebar({ isTrial = false, trialDaysLeft = 0 }: SidebarProps) {
  const [location] = useLocation();
  const { signOut } = useClerk();
  const { user } = useUser();
  const isAdmin = isAdminSession();

  const displayName = user?.firstName
    ? `${user.firstName}${user.lastName ? " " + user.lastName : ""}`
    : user?.emailAddresses?.[0]?.emailAddress ?? "User";

  const initials = user?.firstName
    ? `${user.firstName[0]}${user.lastName?.[0] ?? ""}`.toUpperCase()
    : displayName[0]?.toUpperCase() ?? "U";

  return (
    <aside className="fixed left-0 top-0 h-full w-56 bg-sidebar text-sidebar-foreground flex flex-col z-40">
      <div className="flex items-center gap-2 px-5 py-4 border-b border-sidebar-border">
        <TrendingUp className="w-5 h-5 text-emerald-400" />
        <span className="font-bold text-sm tracking-wide text-white">EcomProfit</span>
        {isAdmin && (
          <span className="ml-auto text-[9px] font-bold uppercase tracking-widest text-violet-400">ADMIN</span>
        )}
        {!isAdmin && isTrial && (
          <span className="ml-auto text-[9px] font-bold uppercase tracking-widest text-amber-400">TRIAL</span>
        )}
      </div>

      <nav className="flex-1 py-3 px-2 overflow-y-auto">
        {navItems.map(({ href, label, icon: Icon }) => {
          const isActive = location === href || location.startsWith(href + "/");
          return (
            <Link
              key={href}
              href={href}
              data-testid={`nav-${label.toLowerCase()}`}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-md mb-0.5 text-sm font-medium transition-colors",
                isActive
                  ? "bg-sidebar-accent text-white"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-white"
              )}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              {label}
            </Link>
          );
        })}

        {isAdmin && (
          <>
            <div className="mx-3 my-2 border-t border-sidebar-border/40" />
            <Link
              href="/admin"
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-md mb-0.5 text-sm font-medium transition-colors",
                location === "/admin"
                  ? "bg-violet-600/30 text-violet-300"
                  : "text-violet-400/70 hover:bg-violet-600/20 hover:text-violet-300"
              )}
            >
              <ShieldCheck className="w-4 h-4 flex-shrink-0" />
              Admin Panel
            </Link>
          </>
        )}

        {/* Trial upgrade nudge */}
        {!isAdmin && isTrial && (
          <>
            <div className="mx-3 my-2 border-t border-sidebar-border/40" />
            <Link
              href="/subscribe"
              className="flex flex-col px-3 py-2.5 rounded-md text-xs transition-colors bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20"
            >
              <div className="flex items-center gap-2 text-amber-400 font-semibold mb-0.5">
                <Clock className="w-3.5 h-3.5" />
                Free Trial
              </div>
              <span className="text-amber-400/70">
                {trialDaysLeft > 0 ? `${trialDaysLeft} days left` : "Expires today"}
              </span>
              <span className="text-amber-300/50 mt-0.5">Tap to remove ads → Rs 499</span>
            </Link>
          </>
        )}
      </nav>

      <div className="border-t border-sidebar-border">
        <div className="px-3 py-3 flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-full bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
            {user?.imageUrl ? (
              <img src={user.imageUrl} alt={displayName} className="w-7 h-7 rounded-full object-cover" />
            ) : (
              <span className="text-xs font-semibold text-emerald-400">{initials}</span>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-white truncate">{displayName}</p>
            <p className="text-[10px] text-sidebar-foreground/40 truncate">
              {user?.emailAddresses?.[0]?.emailAddress}
            </p>
          </div>
          <button
            onClick={() => signOut({ redirectUrl: "/" })}
            title="Sign out"
            className="text-sidebar-foreground/40 hover:text-white transition-colors flex-shrink-0"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
}
