import { Sidebar } from "./sidebar";
import { AdBanner } from "./AdBanner";

interface LayoutProps {
  children: React.ReactNode;
  isTrial?: boolean;
  trialDaysLeft?: number;
}

export function Layout({ children, isTrial = false, trialDaysLeft = 0 }: LayoutProps) {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar isTrial={isTrial} trialDaysLeft={trialDaysLeft} />
      <main className="flex-1 ml-56 min-h-screen overflow-auto flex flex-col">
        {isTrial && <AdBanner />}
        <div className="flex-1">
          {children}
        </div>
        {isTrial && <AdBanner />}
      </main>
    </div>
  );
}
