import { useEffect, useRef, useState } from "react";
import { Switch, Route, Redirect, Router as WouterRouter, useLocation } from "wouter";
import { ClerkProvider, SignIn, SignUp, Show, useClerk, useUser } from "@clerk/react";
import { shadcn } from "@clerk/themes";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout/layout";
import Landing from "@/pages/landing";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Orders from "@/pages/orders";
import Stores from "@/pages/stores";
import Shipments from "@/pages/shipments";
import Costs from "@/pages/costs";
import Reports from "@/pages/reports";
import Integrations from "@/pages/integrations";
import Subscribe from "@/pages/subscribe";
import Admin from "@/pages/admin";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
const clerkPubKey = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY as string;
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const TRIAL_DAYS = 60;

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

const clerkAppearance = {
  baseTheme: shadcn,
  cssLayerName: "clerk" as const,
  options: {
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
    logoPlacement: "inside" as const,
  },
  variables: {
    colorPrimary: "#0f172a",
    colorForeground: "#0f172a",
    colorMutedForeground: "#64748b",
    colorDanger: "#ef4444",
    colorBackground: "#ffffff",
    colorInput: "#f1f5f9",
    colorInputForeground: "#0f172a",
    colorNeutral: "#94a3b8",
    fontFamily: "Inter, sans-serif",
    borderRadius: "0.4rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-white rounded-2xl w-[420px] max-w-full overflow-hidden shadow-lg border border-slate-200",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-slate-900 font-bold",
    headerSubtitle: "text-slate-500",
    socialButtonsBlockButtonText: "text-slate-700 font-medium",
    formFieldLabel: "text-slate-700 text-sm font-medium",
    formFieldInput: "bg-slate-50 border-slate-200 text-slate-900",
    formButtonPrimary: "bg-slate-900 hover:bg-slate-800 text-white",
    footerActionLink: "text-emerald-600 hover:text-emerald-500 font-medium",
    footerActionText: "text-slate-500",
    dividerText: "text-slate-400",
    dividerLine: "bg-slate-200",
    identityPreviewEditButton: "text-emerald-600",
    formFieldSuccessText: "text-emerald-600",
    alertText: "text-slate-700",
    socialButtonsBlockButton: "border-slate-200 hover:bg-slate-50",
    logoBox: "flex justify-center mb-1",
    logoImage: "w-10 h-10",
    footerAction: "bg-slate-50",
    alert: "border-red-100 bg-red-50",
    otpCodeFieldInput: "border-slate-200 bg-slate-50",
    formFieldRow: "gap-3",
    main: "gap-4",
  },
};

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 30_000 },
  },
});

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) {
        qc.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, qc]);

  return null;
}

type SubStatus = "loading" | "active" | "trial" | "pending" | "none" | "rejected";

const ADMIN_SESSION_KEY = "ecom_admin_verified";

export function isAdminSession(): boolean {
  return sessionStorage.getItem(ADMIN_SESSION_KEY) === "1";
}

function getTrialInfo(user: { createdAt?: Date | number | null } | null | undefined) {
  if (!user?.createdAt) return { isInTrial: false, daysLeft: 0, trialEnd: null };
  const createdAt = new Date(user.createdAt);
  const trialEnd = new Date(createdAt.getTime() + TRIAL_DAYS * 24 * 60 * 60 * 1000);
  const now = new Date();
  const isInTrial = now < trialEnd;
  const daysLeft = Math.max(0, Math.ceil((trialEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
  return { isInTrial, daysLeft, trialEnd };
}

function useSubscriptionStatus() {
  const { isSignedIn, user } = useUser();
  const [status, setStatus] = useState<SubStatus>("loading");

  useEffect(() => {
    if (!isSignedIn || !user) {
      setStatus("none");
      return;
    }
    // Admin with verified key bypasses subscription check
    if (isAdminSession()) {
      setStatus("active");
      return;
    }

    const { isInTrial } = getTrialInfo(user);

    fetch("/api/subscriptions/my", { credentials: "include" })
      .then(r => r.ok ? r.json() : { status: "none" })
      .then((data: { status: string }) => {
        if (data.status === "active") {
          setStatus("active"); // Paid — no ads, no trial badge
        } else if (isInTrial) {
          setStatus("trial"); // Free trial — full access + ads
        } else {
          setStatus((data.status as SubStatus) ?? "none");
        }
      })
      .catch(() => setStatus(isInTrial ? "trial" : "none"));
  }, [isSignedIn, user]);

  return status;
}

function SignInPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#f8fafc] px-4">
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
        appearance={clerkAppearance}
      />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#f8fafc] px-4">
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
        appearance={clerkAppearance}
      />
    </div>
  );
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/dashboard" />
      </Show>
      <Show when="signed-out">
        <Landing />
      </Show>
    </>
  );
}

function ProtectedApp() {
  const { user } = useUser();
  const subStatus = useSubscriptionStatus();
  const isTrial = subStatus === "trial";
  const { daysLeft } = getTrialInfo(user);

  return (
    <>
      <Show when="signed-in">
        {subStatus === "loading" ? (
          <div className="min-h-screen flex items-center justify-center bg-[#f8fafc]">
            <div className="text-sm text-slate-400">Loading...</div>
          </div>
        ) : subStatus === "active" || subStatus === "trial" ? (
          <Layout isTrial={isTrial} trialDaysLeft={daysLeft}>
            <Switch>
              <Route path="/dashboard" component={Dashboard} />
              <Route path="/orders" component={Orders} />
              <Route path="/stores" component={Stores} />
              <Route path="/shipments" component={Shipments} />
              <Route path="/costs" component={Costs} />
              <Route path="/reports" component={Reports} />
              <Route path="/integrations" component={Integrations} />
              <Route component={NotFound} />
            </Switch>
          </Layout>
        ) : (
          <Subscribe trialExpired={subStatus === "none"} />
        )}
      </Show>
      <Show when="signed-out">
        <Redirect to="/" />
      </Show>
    </>
  );
}

function AppRouter() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey!}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: "Welcome back", subtitle: "Sign in to your EcomProfit account" } },
        signUp: { start: { title: "Create your account", subtitle: "Start tracking your e-commerce profits" } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <TooltipProvider>
          <Switch>
            <Route path="/" component={HomeRedirect} />
            <Route path="/sign-in/*?" component={SignInPage} />
            <Route path="/sign-up/*?" component={SignUpPage} />
            <Route path="/admin" component={AdminPage} />
            <Route path="/:rest*" component={ProtectedApp} />
          </Switch>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function AdminPage() {
  return (
    <>
      <Show when="signed-in">
        <Admin />
      </Show>
      <Show when="signed-out">
        <Redirect to="/sign-in" />
      </Show>
    </>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <AppRouter />
    </WouterRouter>
  );
}

export default App;
