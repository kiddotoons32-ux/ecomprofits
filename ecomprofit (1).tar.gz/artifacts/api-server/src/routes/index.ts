import { Router, type IRouter } from "express";
import healthRouter from "./health";
import storesRouter from "./stores";
import ordersRouter from "./orders";
import shipmentsRouter from "./shipments";
import costsRouter from "./costs";
import reportsRouter from "./reports";
import integrationsRouter from "./integrations";
import subscriptionsRouter from "./subscriptions";
import referralsRouter from "./referrals";
import { db } from "@workspace/db";
import { settingsTable } from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();

router.use(healthRouter);

// Public: payment details (shown on subscribe page before auth completes)
router.get("/settings/payment", async (_req, res) => {
  try {
    const rows = await db.select().from(settingsTable);
    const map: Record<string, string> = {};
    for (const r of rows) map[r.key] = r.value;
    res.json({
      easypaisaNumber: map["easypaisa_number"] ?? "03152563802",
      bankName: map["bank_name"] ?? "",
      bankAccount: map["bank_account"] ?? "",
      bankTitle: map["bank_title"] ?? "",
      bankIban: map["bank_iban"] ?? "",
    });
  } catch {
    res.json({ easypaisaNumber: "03152563802", bankName: "", bankAccount: "", bankTitle: "", bankIban: "" });
  }
});

router.use(requireAuth);
router.use(storesRouter);
router.use(ordersRouter);
router.use(shipmentsRouter);
router.use(costsRouter);
router.use(reportsRouter);
router.use(integrationsRouter);
router.use(subscriptionsRouter);
router.use(referralsRouter);

export default router;
