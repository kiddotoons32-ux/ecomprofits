import { Router } from "express";
import { db } from "@workspace/db";
import { ordersTable, storesTable } from "@workspace/db";
import { eq, and, sql, inArray } from "drizzle-orm";
import {
  ListOrdersQueryParams,
  CreateOrderBody,
  GetOrderParams,
  UpdateOrderParams,
  UpdateOrderBody,
  DeleteOrderParams,
  BulkImportOrdersBody,
} from "@workspace/api-zod";

const router = Router();

function uid(req: any): string { return req.userId as string; }

async function userStoreIds(userId: string): Promise<number[]> {
  const rows = await db.select({ id: storesTable.id }).from(storesTable)
    .where(eq(storesTable.clerkUserId, userId));
  return rows.map(r => r.id);
}

router.get("/orders", async (req, res) => {
  const params = ListOrdersQueryParams.parse(req.query);
  const storeIds = await userStoreIds(uid(req));
  if (storeIds.length === 0) return res.json({ orders: [], total: 0, page: 1, limit: 50 });

  const conditions: ReturnType<typeof eq>[] = [inArray(ordersTable.storeId, storeIds)];
  if (params.storeId) conditions.push(eq(ordersTable.storeId, params.storeId));
  if (params.status) conditions.push(eq(ordersTable.status, params.status));
  if (params.month) conditions.push(sql`EXTRACT(MONTH FROM ${ordersTable.orderDate}::date) = ${params.month}`);
  if (params.year) conditions.push(sql`EXTRACT(YEAR FROM ${ordersTable.orderDate}::date) = ${params.year}`);

  const page = params.page ?? 1;
  const limit = params.limit ?? 50;
  const offset = (page - 1) * limit;
  const where = and(...conditions);

  const [orders, countResult] = await Promise.all([
    db.select({
      id: ordersTable.id,
      storeId: ordersTable.storeId,
      storeName: storesTable.name,
      orderNumber: ordersTable.orderNumber,
      customerName: ordersTable.customerName,
      customerPhone: ordersTable.customerPhone,
      productName: ordersTable.productName,
      quantity: ordersTable.quantity,
      salePrice: ordersTable.salePrice,
      costPrice: ordersTable.costPrice,
      shippingCharge: ordersTable.shippingCharge,
      packagingCost: ordersTable.packagingCost,
      status: ordersTable.status,
      courier: ordersTable.courier,
      trackingNumber: ordersTable.trackingNumber,
      orderDate: ordersTable.orderDate,
      deliveryDate: ordersTable.deliveryDate,
      notes: ordersTable.notes,
      createdAt: ordersTable.createdAt,
    })
      .from(ordersTable)
      .leftJoin(storesTable, eq(ordersTable.storeId, storesTable.id))
      .where(where)
      .orderBy(ordersTable.orderDate)
      .limit(limit)
      .offset(offset),
    db.select({ count: sql<number>`count(*)::int` }).from(ordersTable).where(where),
  ]);

  res.json({ orders, total: countResult[0]?.count ?? 0, page, limit });
});

router.post("/orders", async (req, res) => {
  const body = CreateOrderBody.parse(req.body);
  const storeIds = await userStoreIds(uid(req));
  if (!storeIds.includes(body.storeId)) return res.status(403).json({ error: "Forbidden" });

  const [order] = await db.insert(ordersTable).values(body).returning();
  const [store] = await db.select().from(storesTable).where(eq(storesTable.id, order.storeId));
  res.status(201).json({ ...order, storeName: store?.name ?? "" });
});

router.post("/orders/bulk-import", async (req, res) => {
  const body = BulkImportOrdersBody.parse(req.body);
  const storeIds = await userStoreIds(uid(req));
  if (!storeIds.includes(body.storeId)) return res.status(403).json({ error: "Forbidden" });

  let imported = 0;
  const errors: string[] = [];
  for (let i = 0; i < body.orders.length; i++) {
    try {
      await db.insert(ordersTable).values({ ...body.orders[i], storeId: body.storeId });
      imported++;
    } catch (err) {
      errors.push(`Row ${i + 1}: ${err instanceof Error ? err.message : "Unknown error"}`);
    }
  }
  res.json({ imported, failed: errors.length, errors });
});

router.get("/orders/:id", async (req, res) => {
  const { id } = GetOrderParams.parse(req.params);
  const storeIds = await userStoreIds(uid(req));
  if (storeIds.length === 0) return res.status(404).json({ error: "Order not found" });

  const [order] = await db.select({
    id: ordersTable.id,
    storeId: ordersTable.storeId,
    storeName: storesTable.name,
    orderNumber: ordersTable.orderNumber,
    customerName: ordersTable.customerName,
    customerPhone: ordersTable.customerPhone,
    productName: ordersTable.productName,
    quantity: ordersTable.quantity,
    salePrice: ordersTable.salePrice,
    costPrice: ordersTable.costPrice,
    shippingCharge: ordersTable.shippingCharge,
    packagingCost: ordersTable.packagingCost,
    status: ordersTable.status,
    courier: ordersTable.courier,
    trackingNumber: ordersTable.trackingNumber,
    orderDate: ordersTable.orderDate,
    deliveryDate: ordersTable.deliveryDate,
    notes: ordersTable.notes,
    createdAt: ordersTable.createdAt,
  })
    .from(ordersTable)
    .leftJoin(storesTable, eq(ordersTable.storeId, storesTable.id))
    .where(and(eq(ordersTable.id, id), inArray(ordersTable.storeId, storeIds)));

  if (!order) return res.status(404).json({ error: "Order not found" });
  res.json(order);
});

router.put("/orders/:id", async (req, res) => {
  const { id } = UpdateOrderParams.parse(req.params);
  const body = UpdateOrderBody.parse(req.body);
  const storeIds = await userStoreIds(uid(req));
  if (storeIds.length === 0) return res.status(404).json({ error: "Order not found" });

  const [order] = await db.update(ordersTable).set(body)
    .where(and(eq(ordersTable.id, id), inArray(ordersTable.storeId, storeIds)))
    .returning();
  if (!order) return res.status(404).json({ error: "Order not found" });
  const [store] = await db.select().from(storesTable).where(eq(storesTable.id, order.storeId));
  res.json({ ...order, storeName: store?.name ?? "" });
});

router.delete("/orders/:id", async (req, res) => {
  const { id } = DeleteOrderParams.parse(req.params);
  const storeIds = await userStoreIds(uid(req));
  if (storeIds.length === 0) return res.status(204).send();
  await db.delete(ordersTable)
    .where(and(eq(ordersTable.id, id), inArray(ordersTable.storeId, storeIds)));
  res.status(204).send();
});

export default router;
