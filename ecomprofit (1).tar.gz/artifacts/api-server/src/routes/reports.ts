import { Router } from "express";
import { db } from "@workspace/db";
import { ordersTable, costsTable, storesTable } from "@workspace/db";
import { eq, and, sql, inArray } from "drizzle-orm";
import {
  GetMonthlyReportQueryParams,
  GetDashboardSummaryQueryParams,
  GetMonthlyTrendsQueryParams,
  GetOrderBreakdownQueryParams,
} from "@workspace/api-zod";

const router = Router();

function uid(req: any): string { return req.userId as string; }

async function userStoreIds(userId: string): Promise<number[]> {
  const rows = await db.select({ id: storesTable.id }).from(storesTable)
    .where(eq(storesTable.clerkUserId, userId));
  return rows.map(r => r.id);
}

async function buildMonthlyReport(
  month: number,
  year: number,
  storeIdsForUser: number[],
  storeId?: number,
) {
  if (storeIdsForUser.length === 0) {
    return emptyReport(month, year);
  }

  const scopedStoreIds = storeId ? [storeId] : storeIdsForUser;
  const validStoreIds = scopedStoreIds.filter(id => storeIdsForUser.includes(id));
  if (validStoreIds.length === 0) return emptyReport(month, year);

  const orderConditions = [
    inArray(ordersTable.storeId, validStoreIds),
    sql`EXTRACT(MONTH FROM ${ordersTable.orderDate}::date) = ${month}`,
    sql`EXTRACT(YEAR FROM ${ordersTable.orderDate}::date) = ${year}`,
  ];

  const costConditions = [
    inArray(costsTable.storeId, validStoreIds),
    eq(costsTable.month, month),
    eq(costsTable.year, year),
  ];

  const [orders, extraCosts] = await Promise.all([
    db.select().from(ordersTable).where(and(...orderConditions)),
    db.select().from(costsTable).where(and(...costConditions)),
  ]);

  return computeReport(month, year, orders, extraCosts);
}

function emptyReport(month: number, year: number) {
  return {
    month, year,
    totalOrders: 0, deliveredOrders: 0, returnedOrders: 0,
    notDeliveredOrders: 0, pendingOrders: 0, cancelledOrders: 0,
    totalRevenue: 0, totalCostOfGoods: 0, totalShippingCost: 0,
    totalPackagingCost: 0, totalOtherCosts: 0,
    grossProfit: 0, netProfit: 0, profitMargin: 0,
    deliveryRate: 0, returnRate: 0,
  };
}

function computeReport(month: number, year: number, orders: any[], extraCosts: any[]) {
  const totalOrders = orders.length;
  const deliveredOrders = orders.filter(o => o.status === "delivered").length;
  const returnedOrders = orders.filter(o => o.status === "returned").length;
  const notDeliveredOrders = orders.filter(o => o.status === "not_delivered").length;
  const pendingOrders = orders.filter(o => o.status === "pending").length;
  const cancelledOrders = orders.filter(o => o.status === "cancelled").length;
  const deliveredOnly = orders.filter(o => o.status === "delivered");

  const totalRevenue = deliveredOnly.reduce((s, o) => s + Number(o.salePrice) * o.quantity, 0);
  const totalCostOfGoods = deliveredOnly.reduce((s, o) => s + Number(o.costPrice) * o.quantity, 0);
  const totalShippingCost =
    orders.reduce((s, o) => s + Number(o.shippingCharge), 0) +
    extraCosts.filter(c => c.type === "shipping").reduce((s, c) => s + Number(c.amount), 0);
  const totalPackagingCost =
    orders.reduce((s, o) => s + Number(o.packagingCost), 0) +
    extraCosts.filter(c => c.type === "packaging").reduce((s, c) => s + Number(c.amount), 0);
  const totalOtherCosts = extraCosts.filter(c => c.type === "other").reduce((s, c) => s + Number(c.amount), 0);

  const grossProfit = totalRevenue - totalCostOfGoods;
  const netProfit = grossProfit - totalShippingCost - totalPackagingCost - totalOtherCosts;
  const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;
  const deliveryRate = totalOrders > 0 ? (deliveredOrders / totalOrders) * 100 : 0;
  const returnRate = totalOrders > 0 ? (returnedOrders / totalOrders) * 100 : 0;

  return {
    month, year, totalOrders, deliveredOrders, returnedOrders,
    notDeliveredOrders, pendingOrders, cancelledOrders,
    totalRevenue, totalCostOfGoods, totalShippingCost,
    totalPackagingCost, totalOtherCosts,
    grossProfit, netProfit, profitMargin, deliveryRate, returnRate,
  };
}

router.get("/reports/monthly", async (req, res) => {
  const params = GetMonthlyReportQueryParams.parse(req.query);
  const storeIds = await userStoreIds(uid(req));
  const report = await buildMonthlyReport(params.month, params.year, storeIds, params.storeId ?? undefined);

  let storeName: string | null = null;
  if (params.storeId) {
    const [store] = await db.select().from(storesTable)
      .where(and(eq(storesTable.id, params.storeId), eq(storesTable.clerkUserId, uid(req))));
    storeName = store?.name ?? null;
  }

  res.json({ ...report, storeName });
});

router.get("/reports/dashboard", async (req, res) => {
  const params = GetDashboardSummaryQueryParams.parse(req.query);
  const storeIds = await userStoreIds(uid(req));

  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();
  const prevMonth = currentMonth === 1 ? 12 : currentMonth - 1;
  const prevYear = currentMonth === 1 ? currentYear - 1 : currentYear;

  const [currentMonthReport, previousMonthReport, stores] = await Promise.all([
    buildMonthlyReport(currentMonth, currentYear, storeIds, params.storeId ?? undefined),
    buildMonthlyReport(prevMonth, prevYear, storeIds, params.storeId ?? undefined),
    storeIds.length > 0
      ? db.select().from(storesTable).where(inArray(storesTable.id, storeIds))
      : Promise.resolve([]),
  ]);

  const totalOrdersResult = storeIds.length > 0
    ? await db.select({ count: sql<number>`count(*)::int` }).from(ordersTable)
        .where(inArray(ordersTable.storeId, storeIds))
    : [{ count: 0 }];

  const storeRevenueMap = new Map<number, number>();
  if (storeIds.length > 0) {
    const monthOrders = await db.select().from(ordersTable).where(
      and(
        inArray(ordersTable.storeId, storeIds),
        sql`EXTRACT(MONTH FROM ${ordersTable.orderDate}::date) = ${currentMonth}`,
        sql`EXTRACT(YEAR FROM ${ordersTable.orderDate}::date) = ${currentYear}`,
        eq(ordersTable.status, "delivered"),
      ),
    );
    for (const o of monthOrders) {
      storeRevenueMap.set(o.storeId, (storeRevenueMap.get(o.storeId) ?? 0) + Number(o.salePrice) * o.quantity);
    }
  }

  let topStore: string | null = null;
  let maxRev = 0;
  for (const [sid, rev] of storeRevenueMap.entries()) {
    if (rev > maxRev) {
      maxRev = rev;
      topStore = stores.find(s => s.id === sid)?.name ?? null;
    }
  }

  res.json({
    currentMonth: currentMonthReport,
    previousMonth: previousMonthReport,
    totalStores: stores.length,
    totalOrdersAllTime: totalOrdersResult[0]?.count ?? 0,
    topStore,
  });
});

router.get("/reports/trends", async (req, res) => {
  const params = GetMonthlyTrendsQueryParams.parse(req.query);
  const storeIds = await userStoreIds(uid(req));
  const months = params.months ?? 6;
  const now = new Date();
  const results = [];

  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const month = d.getMonth() + 1;
    const year = d.getFullYear();
    const report = await buildMonthlyReport(month, year, storeIds, params.storeId ?? undefined);
    const label = d.toLocaleString("en-US", { month: "short", year: "numeric" });
    results.push({ ...report, label });
  }

  res.json(results);
});

router.get("/reports/order-breakdown", async (req, res) => {
  const params = GetOrderBreakdownQueryParams.parse(req.query);
  const storeIds = await userStoreIds(uid(req));
  if (storeIds.length === 0) {
    return res.json({ delivered: 0, returned: 0, notDelivered: 0, pending: 0, cancelled: 0, deliveryRate: 0, returnRate: 0 });
  }

  const conditions: ReturnType<typeof eq>[] = [inArray(ordersTable.storeId, storeIds)];
  if (params.month) conditions.push(sql`EXTRACT(MONTH FROM ${ordersTable.orderDate}::date) = ${params.month}`);
  if (params.year) conditions.push(sql`EXTRACT(YEAR FROM ${ordersTable.orderDate}::date) = ${params.year}`);
  if (params.storeId && storeIds.includes(params.storeId)) conditions.push(eq(ordersTable.storeId, params.storeId));

  const orders = await db.select().from(ordersTable).where(and(...conditions));
  const total = orders.length;
  const delivered = orders.filter(o => o.status === "delivered").length;
  const returned = orders.filter(o => o.status === "returned").length;
  const notDelivered = orders.filter(o => o.status === "not_delivered").length;
  const pending = orders.filter(o => o.status === "pending").length;
  const cancelled = orders.filter(o => o.status === "cancelled").length;

  res.json({
    delivered, returned, notDelivered, pending, cancelled,
    deliveryRate: total > 0 ? (delivered / total) * 100 : 0,
    returnRate: total > 0 ? (returned / total) * 100 : 0,
  });
});

export default router;
