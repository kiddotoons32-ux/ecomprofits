import { Router } from "express";
import { db } from "@workspace/db";
import { subscriptionsTable, settingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../middlewares/requireAuth";

const router = Router();

const ADMIN_USER_ID = process.env.ADMIN_USER_ID ?? "";
const ADMIN_KEY = process.env.ADMIN_KEY ?? "";
const OWNER_WHATSAPP = process.env.OWNER_WHATSAPP ?? "923166931898";
const CALLMEBOT_API_KEY = process.env.CALLMEBOT_API_KEY ?? "";

function isAdmin(userId: string) {
  if (!ADMIN_USER_ID) return true;
  return userId === ADMIN_USER_ID;
}

// ─── WhatsApp notification via CallMeBot ──────────────────────────────────────
async function sendWhatsApp(message: string): Promise<void> {
  if (!CALLMEBOT_API_KEY) return; // silently skip if not configured
  try {
    const encoded = encodeURIComponent(message);
    const url = `https://api.callmebot.com/whatsapp.php?phone=${OWNER_WHATSAPP}&text=${encoded}&apikey=${CALLMEBOT_API_KEY}`;
    await fetch(url);
  } catch {
    // non-critical — don't fail the request
  }
}

// ─── Verify admin key ─────────────────────────────────────────────────────────
router.post("/admin/verify-key", requireAuth, (req, res) => {
  const { key } = req.body as { key?: string };
  if (!ADMIN_KEY) return res.status(503).json({ error: "Admin key not configured" });
  if (!key || key.trim() !== ADMIN_KEY) return res.status(401).json({ error: "Invalid key" });
  res.json({ ok: true });
});

// ─── Submit payment proof ─────────────────────────────────────────────────────
router.post("/subscriptions", requireAuth, async (req, res) => {
  const userId = (req as any).userId as string;
  const { userName, userEmail, paymentMethod, transactionId, senderName, senderNumber, referredByCode } = req.body as {
    userName?: string;
    userEmail?: string;
    paymentMethod: string;
    transactionId: string;
    senderName?: string;
    senderNumber?: string;
    referredByCode?: string;
  };

  if (!paymentMethod || !transactionId) {
    return res.status(400).json({ error: "paymentMethod and transactionId are required" });
  }

  const existing = await db.select().from(subscriptionsTable)
    .where(eq(subscriptionsTable.clerkUserId, userId));

  const active = existing.find(s => s.status === "active");
  if (active) return res.status(400).json({ error: "Already subscribed" });

  const pending = existing.find(s => s.status === "pending");
  if (pending) return res.status(400).json({ error: "Payment already submitted and under review" });

  const [sub] = await db.insert(subscriptionsTable).values({
    clerkUserId: userId,
    userName: userName ?? null,
    userEmail: userEmail ?? null,
    amount: "499",
    paymentMethod,
    transactionId,
    senderName: senderName ?? null,
    senderNumber: senderNumber ?? null,
    referredByCode: referredByCode?.trim().toUpperCase() || null,
    status: "pending",
  }).returning();

  // Notify owner via WhatsApp
  const name = userName ?? senderName ?? "Unknown";
  const method = paymentMethod === "easypaisa" ? "Easypaisa" : "Bank Transfer";
  const phone = senderNumber ? ` | Phone: ${senderNumber}` : "";
  sendWhatsApp(
    `🔔 New Payment Submitted!\n\nName: ${name}\nMethod: ${method}${phone}\nTXN ID: ${transactionId}\nAmount: Rs 499\n\nGo to /admin to approve ✅`
  );

  res.status(201).json(sub);
});

// ─── Get my subscription ──────────────────────────────────────────────────────
router.get("/subscriptions/my", requireAuth, async (req, res) => {
  const userId = (req as any).userId as string;
  const subs = await db.select().from(subscriptionsTable)
    .where(eq(subscriptionsTable.clerkUserId, userId));

  const active = subs.find(s => s.status === "active");
  if (active) return res.json({ status: "active", subscription: active });

  const pending = subs.find(s => s.status === "pending");
  if (pending) return res.json({ status: "pending", subscription: pending });

  const rejected = subs.sort((a, b) =>
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  ).find(s => s.status === "rejected");
  if (rejected) return res.json({ status: "rejected", subscription: rejected });

  return res.json({ status: "none", subscription: null });
});

// ─── Admin: list all submissions ──────────────────────────────────────────────
router.get("/subscriptions/admin", requireAuth, async (req, res) => {
  const userId = (req as any).userId as string;
  if (!isAdmin(userId)) return res.status(403).json({ error: "Forbidden" });

  const subs = await db.select().from(subscriptionsTable)
    .orderBy(subscriptionsTable.createdAt);
  res.json(subs);
});

// ─── Admin: approve ───────────────────────────────────────────────────────────
router.put("/subscriptions/:id/approve", requireAuth, async (req, res) => {
  const userId = (req as any).userId as string;
  if (!isAdmin(userId)) return res.status(403).json({ error: "Forbidden" });

  const id = parseInt(req.params.id, 10);
  const [sub] = await db.update(subscriptionsTable)
    .set({ status: "active", approvedAt: new Date() })
    .where(eq(subscriptionsTable.id, id))
    .returning();
  if (!sub) return res.status(404).json({ error: "Not found" });

  // Notify owner that they approved someone
  const name = sub.userName ?? sub.senderName ?? "User";
  sendWhatsApp(`✅ Payment Approved!\n\nYou approved ${name}'s payment (Rs ${sub.amount}).\nThey now have full access to EcomProfit.`);

  res.json(sub);
});

// ─── Admin: reject ────────────────────────────────────────────────────────────
router.put("/subscriptions/:id/reject", requireAuth, async (req, res) => {
  const userId = (req as any).userId as string;
  if (!isAdmin(userId)) return res.status(403).json({ error: "Forbidden" });

  const id = parseInt(req.params.id, 10);
  const { reason } = req.body as { reason?: string };
  const [sub] = await db.update(subscriptionsTable)
    .set({ status: "rejected", rejectionReason: reason ?? "Payment not verified" })
    .where(eq(subscriptionsTable.id, id))
    .returning();
  if (!sub) return res.status(404).json({ error: "Not found" });
  res.json(sub);
});

// ─── Admin: broadcast client list ─────────────────────────────────────────────
router.get("/broadcast/clients", requireAuth, async (req, res) => {
  const userId = (req as any).userId as string;
  if (!isAdmin(userId)) return res.status(403).json({ error: "Forbidden" });

  const active = await db.select().from(subscriptionsTable)
    .where(eq(subscriptionsTable.status, "active"));

  res.json(active.map(s => ({
    id: s.id,
    name: s.userName ?? s.senderName ?? "Unknown",
    email: s.userEmail ?? null,
    phone: s.senderNumber ?? null,
  })));
});

// ─── Settings: get payment details ────────────────────────────────────────────
router.get("/settings/payment", async (_req, res) => {
  const rows = await db.select().from(settingsTable);
  const map: Record<string, string> = {};
  for (const r of rows) map[r.key] = r.value;
  res.json({
    easypaisaNumber: map["easypaisa_number"] ?? "03152563802",
    bankName: map["bank_name"] ?? "",
    bankAccount: map["bank_account"] ?? "",
    bankTitle: map["bank_title"] ?? "",
    bankIban: map["bank_iban"] ?? "",
  });
});

// ─── Admin: update payment details ────────────────────────────────────────────
router.put("/settings/payment", requireAuth, async (req, res) => {
  const userId = (req as any).userId as string;
  if (!isAdmin(userId)) return res.status(403).json({ error: "Forbidden" });

  const { easypaisaNumber, bankName, bankAccount, bankTitle, bankIban } = req.body as {
    easypaisaNumber?: string;
    bankName?: string;
    bankAccount?: string;
    bankTitle?: string;
    bankIban?: string;
  };

  const pairs: [string, string][] = [
    ["easypaisa_number", easypaisaNumber ?? "03152563802"],
    ["bank_name", bankName ?? ""],
    ["bank_account", bankAccount ?? ""],
    ["bank_title", bankTitle ?? ""],
    ["bank_iban", bankIban ?? ""],
  ];

  for (const [key, value] of pairs) {
    const existing = await db.select().from(settingsTable).where(eq(settingsTable.key, key));
    if (existing.length > 0) {
      await db.update(settingsTable).set({ value, updatedAt: new Date() }).where(eq(settingsTable.key, key));
    } else {
      await db.insert(settingsTable).values({ key, value });
    }
  }

  res.json({ ok: true });
});

export default router;
