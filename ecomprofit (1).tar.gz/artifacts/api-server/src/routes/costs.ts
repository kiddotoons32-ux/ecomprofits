import { Router } from "express";
import { db } from "@workspace/db";
import { costsTable, storesTable } from "@workspace/db";
import { eq, and, inArray } from "drizzle-orm";
import {
  ListCostsQueryParams,
  CreateCostBody,
  UpdateCostParams,
  UpdateCostBody,
  DeleteCostParams,
} from "@workspace/api-zod";

const router = Router();

function uid(req: any): string { return req.userId as string; }

async function userStoreIds(userId: string): Promise<number[]> {
  const rows = await db.select({ id: storesTable.id }).from(storesTable)
    .where(eq(storesTable.clerkUserId, userId));
  return rows.map(r => r.id);
}

router.get("/costs", async (req, res) => {
  const params = ListCostsQueryParams.parse(req.query);
  const storeIds = await userStoreIds(uid(req));
  if (storeIds.length === 0) return res.json([]);

  const conditions: ReturnType<typeof eq>[] = [inArray(costsTable.storeId, storeIds)];
  if (params.storeId) conditions.push(eq(costsTable.storeId, params.storeId));
  if (params.type) conditions.push(eq(costsTable.type, params.type));
  if (params.month) conditions.push(eq(costsTable.month, params.month));
  if (params.year) conditions.push(eq(costsTable.year, params.year));

  const costs = await db.select({
    id: costsTable.id,
    storeId: costsTable.storeId,
    storeName: storesTable.name,
    type: costsTable.type,
    description: costsTable.description,
    amount: costsTable.amount,
    month: costsTable.month,
    year: costsTable.year,
    createdAt: costsTable.createdAt,
  })
    .from(costsTable)
    .leftJoin(storesTable, eq(costsTable.storeId, storesTable.id))
    .where(and(...conditions))
    .orderBy(costsTable.year, costsTable.month);

  res.json(costs);
});

router.post("/costs", async (req, res) => {
  const body = CreateCostBody.parse(req.body);
  const storeIds = await userStoreIds(uid(req));
  if (!storeIds.includes(body.storeId)) return res.status(403).json({ error: "Forbidden" });

  const [cost] = await db.insert(costsTable).values(body).returning();
  const [store] = await db.select().from(storesTable).where(eq(storesTable.id, cost.storeId));
  res.status(201).json({ ...cost, storeName: store?.name ?? "" });
});

router.put("/costs/:id", async (req, res) => {
  const { id } = UpdateCostParams.parse(req.params);
  const body = UpdateCostBody.parse(req.body);
  const storeIds = await userStoreIds(uid(req));
  if (storeIds.length === 0) return res.status(404).json({ error: "Cost not found" });

  const [cost] = await db.update(costsTable).set(body)
    .where(and(eq(costsTable.id, id), inArray(costsTable.storeId, storeIds)))
    .returning();
  if (!cost) return res.status(404).json({ error: "Cost not found" });
  const [store] = await db.select().from(storesTable).where(eq(storesTable.id, cost.storeId));
  res.json({ ...cost, storeName: store?.name ?? "" });
});

router.delete("/costs/:id", async (req, res) => {
  const { id } = DeleteCostParams.parse(req.params);
  const storeIds = await userStoreIds(uid(req));
  if (storeIds.length === 0) return res.status(204).send();
  await db.delete(costsTable)
    .where(and(eq(costsTable.id, id), inArray(costsTable.storeId, storeIds)));
  res.status(204).send();
});

export default router;
