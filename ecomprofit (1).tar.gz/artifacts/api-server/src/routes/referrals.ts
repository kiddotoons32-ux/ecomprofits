import { Router } from "express";
import { db } from "@workspace/db";
import { subscriptionsTable, settingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../middlewares/requireAuth";

const router = Router();

const ADMIN_USER_ID = process.env.ADMIN_USER_ID ?? "";

function isAdmin(userId: string) {
  if (!ADMIN_USER_ID) return true;
  return userId === ADMIN_USER_ID;
}

function generateCode(clerkUserId: string): string {
  const raw = clerkUserId.replace("user_", "").toUpperCase();
  return raw.slice(0, 8);
}

async function getOrCreateCode(userId: string): Promise<string> {
  const key = `ref_code_${userId}`;
  const rows = await db.select().from(settingsTable).where(eq(settingsTable.key, key));
  if (rows.length > 0) return rows[0].value;
  const code = generateCode(userId);
  await db.insert(settingsTable).values({ key, value: code }).onConflictDoNothing();
  return code;
}

// ─── Get my referral code + stats ────────────────────────────────────────────
router.get("/referrals/my", requireAuth, async (req, res) => {
  const userId = (req as any).userId as string;
  const code = await getOrCreateCode(userId);

  const allSubs = await db.select().from(subscriptionsTable);
  const referredSubs = allSubs.filter(s => s.referredByCode === code);
  const activatedCount = referredSubs.filter(s => s.status === "active").length;

  res.json({
    code,
    referralLink: null,
    totalReferred: referredSubs.length,
    activatedCount,
    referred: referredSubs.map(s => ({
      name: s.userName ?? s.senderName ?? "Unknown",
      email: s.userEmail ?? null,
      status: s.status,
      date: s.createdAt,
    })),
  });
});

// ─── Admin: all referral stats ────────────────────────────────────────────────
router.get("/referrals/admin", requireAuth, async (req, res) => {
  const userId = (req as any).userId as string;
  if (!isAdmin(userId)) return res.status(403).json({ error: "Forbidden" });

  const allSubs = await db.select().from(subscriptionsTable);
  const allSettings = await db.select().from(settingsTable);

  const codeToUser: Record<string, string> = {};
  for (const s of allSettings) {
    if (s.key.startsWith("ref_code_")) {
      const uid = s.key.replace("ref_code_", "");
      codeToUser[s.value] = uid;
    }
  }

  const referralCounts: Record<string, { total: number; activated: number; code: string }> = {};
  for (const sub of allSubs) {
    if (!sub.referredByCode) continue;
    const code = sub.referredByCode;
    if (!referralCounts[code]) referralCounts[code] = { total: 0, activated: 0, code };
    referralCounts[code].total++;
    if (sub.status === "active") referralCounts[code].activated++;
  }

  const leaderboard = Object.entries(referralCounts)
    .map(([code, stats]) => ({ code, ...stats, referrerId: codeToUser[code] ?? "unknown" }))
    .sort((a, b) => b.activated - a.activated);

  res.json({ leaderboard, totalWithReferral: allSubs.filter(s => s.referredByCode).length });
});

export default router;
