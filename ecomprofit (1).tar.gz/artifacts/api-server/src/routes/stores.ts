import { Router } from "express";
import { db } from "@workspace/db";
import { storesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  CreateStoreBody,
  GetStoreParams,
  UpdateStoreBody,
  UpdateStoreParams,
  DeleteStoreParams,
} from "@workspace/api-zod";

const router = Router();

function userId(req: any): string {
  return req.userId as string;
}

router.get("/stores", async (req, res) => {
  const stores = await db
    .select()
    .from(storesTable)
    .where(eq(storesTable.clerkUserId, userId(req)))
    .orderBy(storesTable.createdAt);
  res.json(stores);
});

router.post("/stores", async (req, res) => {
  const body = CreateStoreBody.parse(req.body);
  const [store] = await db
    .insert(storesTable)
    .values({ ...body, clerkUserId: userId(req) })
    .returning();
  res.status(201).json(store);
});

router.get("/stores/:id", async (req, res) => {
  const { id } = GetStoreParams.parse(req.params);
  const [store] = await db
    .select()
    .from(storesTable)
    .where(and(eq(storesTable.id, id), eq(storesTable.clerkUserId, userId(req))));
  if (!store) return res.status(404).json({ error: "Store not found" });
  res.json(store);
});

router.put("/stores/:id", async (req, res) => {
  const { id } = UpdateStoreParams.parse(req.params);
  const body = UpdateStoreBody.parse(req.body);
  const [store] = await db
    .update(storesTable)
    .set(body)
    .where(and(eq(storesTable.id, id), eq(storesTable.clerkUserId, userId(req))))
    .returning();
  if (!store) return res.status(404).json({ error: "Store not found" });
  res.json(store);
});

router.delete("/stores/:id", async (req, res) => {
  const { id } = DeleteStoreParams.parse(req.params);
  await db
    .delete(storesTable)
    .where(and(eq(storesTable.id, id), eq(storesTable.clerkUserId, userId(req))));
  res.status(204).send();
});

export default router;
