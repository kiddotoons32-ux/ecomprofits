import { Router } from "express";
import { db } from "@workspace/db";
import { storesTable, ordersTable } from "@workspace/db";
import { eq, and, inArray } from "drizzle-orm";

const router = Router();

function uid(req: any): string { return req.userId as string; }

async function getOwnedStore(storeId: number, userId: string) {
  const [store] = await db.select().from(storesTable)
    .where(and(eq(storesTable.id, storeId), eq(storesTable.clerkUserId, userId)));
  return store ?? null;
}

// ─── Shopify Sync ─────────────────────────────────────────────────────────────

const SHOPIFY_API_VERSION = "2024-01";

function mapShopifyStatus(shopifyStatus: string, financialStatus: string): string {
  if (financialStatus === "refunded" || financialStatus === "partially_refunded") return "returned";
  if (shopifyStatus === "fulfilled") return "delivered";
  if (shopifyStatus === "cancelled") return "cancelled";
  return "pending";
}

router.post("/stores/:id/sync-shopify", async (req, res) => {
  const storeId = parseInt(req.params.id, 10);
  if (isNaN(storeId)) return res.status(400).json({ error: "Invalid store ID" });

  const store = await getOwnedStore(storeId, uid(req));
  if (!store) return res.status(404).json({ error: "Store not found" });
  if (store.platform !== "shopify") return res.status(400).json({ error: "Store is not a Shopify store" });
  if (!store.shopifyDomain) return res.status(400).json({ error: "Shopify domain not configured" });
  if (!store.shopifyApiToken) return res.status(400).json({ error: "Shopify API token not configured" });

  const domain = store.shopifyDomain.replace(/^https?:\/\//, "").replace(/\/$/, "");
  const url = `https://${domain}/admin/api/${SHOPIFY_API_VERSION}/orders.json?status=any&limit=250`;

  let shopifyOrders: any[];
  try {
    const resp = await fetch(url, {
      headers: {
        "X-Shopify-Access-Token": store.shopifyApiToken,
        "Content-Type": "application/json",
      },
    });
    if (!resp.ok) {
      const text = await resp.text();
      return res.status(400).json({ error: `Shopify API error: ${resp.status} ${text}` });
    }
    const data = await resp.json() as { orders: any[] };
    shopifyOrders = data.orders ?? [];
  } catch (err: any) {
    return res.status(500).json({ error: `Failed to reach Shopify: ${err.message}` });
  }

  let imported = 0;
  let skipped = 0;
  const errors: string[] = [];

  for (const order of shopifyOrders) {
    try {
      const orderNumber = String(order.order_number ?? order.id);
      const existing = await db.select({ id: ordersTable.id })
        .from(ordersTable)
        .where(and(eq(ordersTable.storeId, storeId), eq(ordersTable.orderNumber, orderNumber)));

      if (existing.length > 0) { skipped++; continue; }

      const lineItem = order.line_items?.[0];
      const productName = lineItem?.name ?? "Unknown Product";
      const quantity = lineItem?.quantity ?? 1;
      const salePrice = parseFloat(order.total_price ?? "0");
      const shippingLine = order.shipping_lines?.[0];
      const shippingCharge = parseFloat(shippingLine?.price ?? "0");
      const customerName = order.customer
        ? `${order.customer.first_name ?? ""} ${order.customer.last_name ?? ""}`.trim()
        : null;
      const customerPhone = order.customer?.phone ?? order.billing_address?.phone ?? null;
      const orderDate = (order.created_at ?? new Date().toISOString()).split("T")[0];
      const status = mapShopifyStatus(order.fulfillment_status ?? "", order.financial_status ?? "");

      await db.insert(ordersTable).values({
        storeId,
        orderNumber,
        customerName: customerName || null,
        customerPhone: customerPhone || null,
        productName,
        quantity,
        salePrice: salePrice.toFixed(2),
        costPrice: "0",
        shippingCharge: shippingCharge.toFixed(2),
        packagingCost: "0",
        status,
        courier: null,
        trackingNumber: order.fulfillments?.[0]?.tracking_number ?? null,
        orderDate,
        deliveryDate: null,
        notes: `Imported from Shopify #${orderNumber}`,
      });
      imported++;
    } catch (err: any) {
      errors.push(`Order ${order.order_number}: ${err.message}`);
    }
  }

  res.json({ imported, skipped, total: shopifyOrders.length, errors });
});

// ─── PostEx Sync ──────────────────────────────────────────────────────────────

const POSTEX_STATUS_MAP: Record<string, string> = {
  "Delivered": "delivered",
  "Returned": "returned",
  "RTO": "returned",
  "Return": "returned",
  "Undelivered": "not_delivered",
  "Not Delivered": "not_delivered",
  "In Transit": "pending",
  "Pending": "pending",
  "Booked": "pending",
  "Out for Delivery": "pending",
  "Shipment Accepted": "pending",
};

router.post("/stores/:id/sync-postex", async (req, res) => {
  const storeId = parseInt(req.params.id, 10);
  if (isNaN(storeId)) return res.status(400).json({ error: "Invalid store ID" });

  const store = await getOwnedStore(storeId, uid(req));
  if (!store) return res.status(404).json({ error: "Store not found" });
  if (!store.postexApiKey) return res.status(400).json({ error: "PostEx API key not configured" });

  const orders = await db.select().from(ordersTable).where(
    and(
      eq(ordersTable.storeId, storeId),
      inArray(ordersTable.courier, ["postex", "PostEx", "POSTEX"])
    )
  );

  const trackable = orders.filter(o => o.trackingNumber && o.status === "pending");
  if (trackable.length === 0) {
    return res.json({ updated: 0, skipped: 0, message: "No pending PostEx orders to sync" });
  }

  let updated = 0;
  let skipped = 0;
  const errors: string[] = [];

  for (const order of trackable) {
    try {
      const resp = await fetch(
        `https://api.postex.pk/services/integration/api/order/v3/order-detail?trackingNumber=${order.trackingNumber}`,
        {
          headers: {
            "token": store.postexApiKey,
            "Content-Type": "application/json",
          },
        }
      );

      if (!resp.ok) { skipped++; continue; }

      const data = await resp.json() as { dist?: { orderStatus?: string; deliveryDate?: string } };
      const rawStatus = data?.dist?.orderStatus ?? "";
      const mappedStatus = POSTEX_STATUS_MAP[rawStatus];

      if (!mappedStatus || mappedStatus === order.status) { skipped++; continue; }

      const deliveryDate = mappedStatus === "delivered"
        ? (data.dist?.deliveryDate?.split("T")[0] ?? new Date().toISOString().split("T")[0])
        : null;

      await db.update(ordersTable)
        .set({ status: mappedStatus, deliveryDate })
        .where(eq(ordersTable.id, order.id));
      updated++;
    } catch (err: any) {
      errors.push(`Order ${order.orderNumber}: ${err.message}`);
    }
  }

  res.json({ updated, skipped, total: trackable.length, errors });
});

// ─── Save integration credentials ────────────────────────────────────────────

router.put("/stores/:id/integrations", async (req, res) => {
  const storeId = parseInt(req.params.id, 10);
  if (isNaN(storeId)) return res.status(400).json({ error: "Invalid store ID" });

  const store = await getOwnedStore(storeId, uid(req));
  if (!store) return res.status(404).json({ error: "Store not found" });

  const { shopifyApiToken, postexApiKey } = req.body as {
    shopifyApiToken?: string | null;
    postexApiKey?: string | null;
  };

  const [updated] = await db.update(storesTable)
    .set({
      shopifyApiToken: shopifyApiToken ?? null,
      postexApiKey: postexApiKey ?? null,
    })
    .where(and(eq(storesTable.id, storeId), eq(storesTable.clerkUserId, uid(req))))
    .returning();

  if (!updated) return res.status(404).json({ error: "Store not found" });
  res.json({ ok: true });
});

export default router;
