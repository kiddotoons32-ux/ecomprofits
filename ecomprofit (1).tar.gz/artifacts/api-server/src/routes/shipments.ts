import { Router } from "express";
import { db } from "@workspace/db";
import { shipmentsTable, ordersTable, storesTable } from "@workspace/db";
import { eq, and, inArray } from "drizzle-orm";
import {
  ListShipmentsQueryParams,
  CreateShipmentBody,
  UpdateShipmentParams,
  UpdateShipmentBody,
} from "@workspace/api-zod";

const router = Router();

function uid(req: any): string { return req.userId as string; }

async function userStoreIds(userId: string): Promise<number[]> {
  const rows = await db.select({ id: storesTable.id }).from(storesTable)
    .where(eq(storesTable.clerkUserId, userId));
  return rows.map(r => r.id);
}

async function userOrderIds(storeIds: number[]): Promise<number[]> {
  if (storeIds.length === 0) return [];
  const rows = await db.select({ id: ordersTable.id }).from(ordersTable)
    .where(inArray(ordersTable.storeId, storeIds));
  return rows.map(r => r.id);
}

router.get("/shipments", async (req, res) => {
  const params = ListShipmentsQueryParams.parse(req.query);
  const storeIds = await userStoreIds(uid(req));
  const orderIds = await userOrderIds(storeIds);
  if (orderIds.length === 0) return res.json([]);

  const conditions: ReturnType<typeof eq>[] = [inArray(shipmentsTable.orderId, orderIds)];
  if (params.orderId) conditions.push(eq(shipmentsTable.orderId, params.orderId));
  if (params.status) conditions.push(eq(shipmentsTable.status, params.status));
  if (params.courier) conditions.push(eq(shipmentsTable.courier, params.courier));

  const shipments = await db.select({
    id: shipmentsTable.id,
    orderId: shipmentsTable.orderId,
    orderNumber: ordersTable.orderNumber,
    courier: shipmentsTable.courier,
    trackingNumber: shipmentsTable.trackingNumber,
    status: shipmentsTable.status,
    shippingCost: shipmentsTable.shippingCost,
    dispatchDate: shipmentsTable.dispatchDate,
    deliveryDate: shipmentsTable.deliveryDate,
    notes: shipmentsTable.notes,
    createdAt: shipmentsTable.createdAt,
  })
    .from(shipmentsTable)
    .leftJoin(ordersTable, eq(shipmentsTable.orderId, ordersTable.id))
    .where(and(...conditions))
    .orderBy(shipmentsTable.createdAt);

  res.json(shipments);
});

router.post("/shipments", async (req, res) => {
  const body = CreateShipmentBody.parse(req.body);
  const storeIds = await userStoreIds(uid(req));
  const orderIds = await userOrderIds(storeIds);
  if (!orderIds.includes(body.orderId)) return res.status(403).json({ error: "Forbidden" });

  const [shipment] = await db.insert(shipmentsTable).values(body).returning();
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, shipment.orderId));
  res.status(201).json({ ...shipment, orderNumber: order?.orderNumber ?? "" });
});

router.put("/shipments/:id", async (req, res) => {
  const { id } = UpdateShipmentParams.parse(req.params);
  const body = UpdateShipmentBody.parse(req.body);
  const storeIds = await userStoreIds(uid(req));
  const orderIds = await userOrderIds(storeIds);
  if (orderIds.length === 0) return res.status(404).json({ error: "Shipment not found" });

  const [shipment] = await db.update(shipmentsTable).set(body)
    .where(and(eq(shipmentsTable.id, id), inArray(shipmentsTable.orderId, orderIds)))
    .returning();
  if (!shipment) return res.status(404).json({ error: "Shipment not found" });
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, shipment.orderId));
  res.json({ ...shipment, orderNumber: order?.orderNumber ?? "" });
});

export default router;
