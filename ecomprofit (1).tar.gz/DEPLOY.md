# Deploy EcomProfit — Free Forever on Render.com

Follow these steps exactly. Takes about 15 minutes.

---

## Step 1 — Get your code on GitHub (free)

1. Go to **github.com** → Sign up for a free account
2. Click **"New repository"** → name it `ecomprofit` → click **Create repository**
3. Come back to Replit → click the **Git icon** on the left sidebar
4. Click **"Connect to GitHub"** → authorize → select your `ecomprofit` repo
5. Click **Commit & Push** — your code is now on GitHub

---

## Step 2 — Create a free database on Neon (free forever)

1. Go to **neon.tech** → Sign up free (use Google login)
2. Click **"New Project"** → name it `ecomprofit` → region: **Singapore** → Create
3. On the dashboard, click **"Connection string"** → copy the full URL
   - It looks like: `postgresql://user:password@host/dbname?sslmode=require`
4. **Save this URL** — you'll need it in Step 4

---

## Step 3 — Deploy on Render (free forever)

1. Go to **render.com** → Sign up free (use GitHub login)
2. Click **"New +"** → **"Web Service"**
3. Click **"Connect a repository"** → select your `ecomprofit` GitHub repo
4. Render will auto-detect the `render.yaml` file — click **"Apply"**
5. You'll see a service called **ecomprofit** being created

---

## Step 4 — Add your secret environment variables on Render

In your Render service dashboard → click **"Environment"** tab → add these:

| Key | Value |
|-----|-------|
| `DATABASE_URL` | Paste your Neon connection string from Step 2 |
| `CLERK_PUBLISHABLE_KEY` | Get from Replit Secrets (same value) |
| `CLERK_SECRET_KEY` | Get from Replit Secrets (same value) |
| `CALLMEBOT_API_KEY` | Get from Replit Secrets (same value) |

Click **"Save Changes"** → Render will redeploy automatically.

---

## Step 5 — Run the database setup

After first deploy, in Render dashboard:
1. Click your service → **"Shell"** tab
2. Run this command:
   ```
   node -e "import('./artifacts/api-server/dist/index.mjs')" 
   ```
   Actually just go to your Render service URL — the DB tables are created automatically on first start.

---

## Step 6 — Allow your Render domain in Clerk

1. Go to your Render service → copy your URL (e.g. `https://ecomprofit.onrender.com`)
2. In Replit → click **Auth** in the left toolbar → **Domains** or **Allowed Origins**
3. Add your Render URL
4. Save

---

## Your app is now live!

- **Public URL**: `https://ecomprofit.onrender.com`
- **Admin panel**: `https://ecomprofit.onrender.com/admin`
- **Admin key**: `ecom-kknb-mm3h`

> Note: On the free Render plan, the server sleeps after 15 minutes of no traffic.
> It wakes up within 30 seconds when someone visits. To keep it always awake,
> use a free uptime monitor like **uptimerobot.com** to ping your URL every 5 minutes.

---

## Replit Secrets to copy to Render

Open Replit → click the lock icon (Secrets) → you'll see:
- `CLERK_PUBLISHABLE_KEY`
- `CLERK_SECRET_KEY`  
- `CALLMEBOT_API_KEY`
- `SESSION_SECRET`

Copy each value and add them to Render's Environment tab.
